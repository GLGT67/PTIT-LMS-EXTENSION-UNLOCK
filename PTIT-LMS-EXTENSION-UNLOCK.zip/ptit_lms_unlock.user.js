// ==UserScript==
// @name         PTIT LMS & S-Link - Extension Unlock
// @namespace    https://lms.ptit.edu.vn/
// @version      2.5.0
// @description  Tự động nhận diện môn học, đồng bộ đáp án GitHub & nạp file JSON, mở khóa tua video LMS PTIT, tự động điền đánh giá S-Link PTIT.
// @author       GLGT67
// @homepageURL  https://github.com/GLGT67/PTIT-LMS-EXTENSION-UNLOCK
// @match        https://lms.ptit.edu.vn/*
// @match        https://slink.ptit.edu.vn/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

/**
 * PTIT LMS & S-Link Extension Unlock (Version 2.5.0)
 * Developed by GLGT67 (https://github.com/GLGT67)
 * Repository: https://github.com/GLGT67/PTIT-LMS-EXTENSION-UNLOCK
 * 
 * Features:
 * 1. LMS PTIT: Mở khóa tua video, tăng tốc độ 1x-16x, phím tắt điều khiển.
 * 2. S-Link PTIT: Tự động phát hiện và điền đánh giá bài giảng / giảng viên ngẫu nhiên 4-5 sao (tùy chọn Năm sinh viên).
 * 3. LMS PTIT Auto-Quiz: Nhận diện mã môn/bài học, tự động giải quiz, đồng bộ 1-chạm GitHub, nộp bài & Auto-Loop.
 */

(function () {
  'use strict';

  if (window.__PTIT_EXTENSION_UNLOCKED_v25__) return;
  window.__PTIT_EXTENSION_UNLOCKED_v25__ = true;

  console.log('%c[PTIT Extension Unlock 2.5] Developed by GLGT67 (https://github.com/GLGT67)', 'color: #10b981; font-weight: bold; font-size: 14px;');

  const hostname = window.location.hostname;
  const isLMS = hostname.includes('lms.ptit.edu.vn');
  const isSLink = hostname.includes('slink.ptit.edu.vn');

  function showToast(msg) {
    let toast = document.getElementById('ptit-lms-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ptit-lms-toast';
      toast.style.cssText = [
        'position: fixed',
        'top: 24px',
        'right: 24px',
        'background: rgba(15, 23, 42, 0.95)',
        'color: #ffffff',
        'padding: 12px 20px',
        'border-radius: 10px',
        'font-family: system-ui, -apple-system, sans-serif',
        'font-size: 14px',
        'font-weight: 600',
        'z-index: 2147483647',
        'box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5)',
        'border: 1px solid rgba(255, 255, 255, 0.2)',
        'transition: opacity 0.25s ease, transform 0.25s ease',
        'pointer-events: none',
        'opacity: 0'
      ].join(';');
      (document.body || document.documentElement).appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
    clearTimeout(toast.__timer);
    toast.__timer = setTimeout(() => {
      toast.style.opacity = '0';
    }, 2500);
  }

  if (isLMS || (!isSLink && document.querySelector('video'))) {
    initLMSVideoUnlocker();
  }

  function initLMSVideoUnlocker() {
    window.addEventListener('mousedown', function (e) {
      if (e.target && (e.target.tagName === 'VIDEO' || e.target.closest('video'))) {
        e.stopImmediatePropagation();
      }
    }, true);

    window.addEventListener('seeking', function (e) {
      if (e.target && e.target.tagName === 'VIDEO') {
        e.stopImmediatePropagation();
      }
    }, true);

    window.addEventListener('seeked', function (e) {
      if (e.target && e.target.tagName === 'VIDEO') {
        e.stopImmediatePropagation();
      }
    }, true);

    const blockSnapback = function (proto) {
      const orig = proto.addEventListener;
      proto.addEventListener = function (type, listener, options) {
        if (type === 'seeking' || type === 'seeked') {
          const fnStr = listener ? listener.toString() : '';
          if (fnStr.includes('currentTime') && (fnStr.includes('Math.max') || fnStr.includes('_.current') || fnStr.includes('maxWatched'))) {
            console.log('[PTIT LMS Extension Unlock 2.3] Đã chặn listener khóa tua:', type);
            return;
          }
        }
        return orig.call(this, type, listener, options);
      };
    };

    blockSnapback(HTMLMediaElement.prototype);
    blockSnapback(EventTarget.prototype);

    function unlockVideo(v) {
      if (!v || v.__ptit_v23_unlocked__) return;
      v.__ptit_v23_unlocked__ = true;

      v.controls = true;
      v.removeAttribute('controlsList');
      v.removeAttribute('disablepictureinpicture');

      console.log('[PTIT LMS Extension Unlock 2.5] Đã mở khóa video:', v);
    }

    function scanVideos() {
      document.querySelectorAll('video').forEach(unlockVideo);

      if (window.YT && window.YT.Player && window.YT.Player.prototype) {
        const p = window.YT.Player.prototype;
        if (!p.__ptit_hooked__) {
          p.__ptit_hooked__ = true;
          const origSeekTo = p.seekTo;
          p.seekTo = function (sec, ahead) {
            return origSeekTo.call(this, sec, true);
          };
        }
      }
    }

    const observer = new MutationObserver(scanVideos);
    if (document.documentElement) {
      observer.observe(document.documentElement, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.documentElement, { childList: true, subtree: true });
      });
    }
    setInterval(scanVideos, 1000);

    window.addEventListener('keydown', function (e) {
      if (['INPUT', 'TEXTAREA'].includes(e.target.tagName) || e.target.isContentEditable) return;

      const video = Array.from(document.querySelectorAll('video')).find(v => !v.paused) || document.querySelector('video');
      if (!video) return;

      if (e.key === 'ArrowRight') {
        e.preventDefault();
        video.currentTime = Math.min(video.duration || 999999, video.currentTime + 5);
        showToast('⏩ Tua tới: ' + Math.round(video.currentTime) + 's');
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        video.currentTime = Math.max(0, video.currentTime - 5);
        showToast('⏪ Tua lùi: ' + Math.round(video.currentTime) + 's');
      } else if (e.key === ']' || e.key === '=' || e.key === '+') {
        e.preventDefault();
        const speeds = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 16.0];
        const cur = video.playbackRate;
        const next = speeds.find(s => s > cur + 0.05) || 16.0;
        video.playbackRate = next;
        showToast('⚡ Tốc độ: ' + next + 'x');
      } else if (e.key === '[' || e.key === '-' || e.key === '_') {
        e.preventDefault();
        const speeds = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 16.0];
        const cur = video.playbackRate;
        const prev = [...speeds].reverse().find(s => s < cur - 0.05) || 1.0;
        video.playbackRate = prev;
        showToast('⚡ Tốc độ: ' + prev + 'x');
      }
    }, true);
  }

  if (isSLink || (!isLMS && window.location.href.includes('danh-gia-giang-vien'))) {
    initSLinkEvaluator();
  }

  function initSLinkEvaluator() {
    let hudElement = null;
    let isMinimized = false;

    function triggerTextInput(inputElement, text) {
      if (!inputElement) return;
      try {
        const proto = Object.getPrototypeOf(inputElement);
        const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
        if (desc && desc.set) {
          desc.set.call(inputElement, text);
        } else {
          inputElement.value = text;
        }
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        inputElement.dispatchEvent(new Event('change', { bubbles: true }));
      } catch (e) {
        inputElement.value = text;
      }
    }

    function isEvaluationPage() {
      const url = window.location.href;
      if (url.includes('danh-gia-giang-vien') || url.includes('khao-sat')) return true;

      const bodyText = document.body ? document.body.innerText : '';
      if (bodyText.includes('ĐÁNH GIÁ GIẢNG VIÊN') ||
          bodyText.includes('PHIẾU KHẢO SÁT Ý KIẾN NGƯỜI HỌC') ||
          bodyText.includes('Đợt đánh giá') ||
          bodyText.includes('Chất lượng bài giảng điện tử')) {
        return true;
      }

      if (document.querySelector('table') && (document.querySelector('.ant-radio-wrapper') || document.querySelector('.ant-checkbox-wrapper'))) {
        return true;
      }

      return false;
    }

    function runAutoFill() {
      let filledCount = 0;
      const savedYear = localStorage.getItem('ptit_slink_student_year') || 'Năm 3';

      function safeClickOption(element) {
        if (!element) return false;
        let clickable = element;
        if (element.tagName === 'TD' || element.tagName === 'DIV') {
          clickable = element.querySelector('label, .ant-checkbox-wrapper, .ant-radio-wrapper, .ant-checkbox, .ant-radio, input') || element;
        }
        const input = clickable.tagName === 'INPUT' ? clickable : clickable.querySelector('input');

        const isAlreadyChecked = (input && input.checked) ||
          (clickable.classList && (
            clickable.classList.contains('ant-checkbox-wrapper-checked') ||
            clickable.classList.contains('ant-radio-wrapper-checked') ||
            clickable.classList.contains('ant-checkbox-checked') ||
            clickable.classList.contains('ant-radio-checked')
          )) ||
          (element.classList && (
            element.classList.contains('ant-checkbox-wrapper-checked') ||
            element.classList.contains('ant-radio-wrapper-checked') ||
            element.classList.contains('ant-checkbox-checked') ||
            element.classList.contains('ant-radio-checked')
          ));

        if (isAlreadyChecked) return true;

        const targetToClick = clickable.querySelector('label, .ant-checkbox-wrapper, .ant-radio-wrapper') ||
                              (clickable.tagName === 'LABEL' ? clickable : null) ||
                              input ||
                              clickable;

        try {
          targetToClick.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
          targetToClick.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
          targetToClick.click();
        } catch (err) {
          targetToClick.click && targetToClick.click();
        }

        if (input && !input.checked) {
          try {
            const proto = Object.getPrototypeOf(input);
            const desc = Object.getOwnPropertyDescriptor(proto, 'checked') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked');
            if (desc && desc.set) {
              desc.set.call(input, true);
            } else {
              input.checked = true;
            }
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (e) {
            input.checked = true;
          }
        }

        filledCount++;
        return true;
      }

      function findOptionByText(keywords) {
        const allCandidates = Array.from(document.querySelectorAll('label, .ant-radio-wrapper, .ant-checkbox-wrapper, span, div'));
        for (const kw of keywords) {
          const kwLower = kw.toLowerCase();
          const found = allCandidates.find(el => {
            const txt = (el.textContent || '').trim().toLowerCase();
            return txt.includes(kwLower) && txt.length < 150;
          });
          if (found) {
            return found.closest('.ant-radio-wrapper, .ant-checkbox-wrapper, label, td') || found;
          }
        }
        return null;
      }

      function findOptionByExactText(text) {
        const allCandidates = Array.from(document.querySelectorAll('label, .ant-radio-wrapper, .ant-checkbox-wrapper, span'));
        const found = allCandidates.find(el => (el.textContent || '').trim() === text);
        if (found) {
          return found.closest('.ant-radio-wrapper, .ant-checkbox-wrapper, label, td') || found;
        }
        return null;
      }

      const a1 = findOptionByText(['kết hợp (blended', 'học kết hợp', 'blended learning', 'kết hợp', 'trực tuyến hoàn toàn']);
      safeClickOption(a1);

      const a2 = findOptionByText(['máy tính/laptop', 'máy tính', 'laptop', 'điện thoại']);
      safeClickOption(a2);

      const a3 = findOptionByText(['100% (hoàn thành', '100%', '76–99%']);
      safeClickOption(a3);

      const a4 = findOptionByExactText(savedYear) || findOptionByText([savedYear]);
      safeClickOption(a4);

      const allRows = Array.from(document.querySelectorAll('tr, .ant-table-row'));
      allRows.forEach(tr => {
        if (tr.querySelector('th') || tr.closest('thead')) return;

        const cells = Array.from(tr.querySelectorAll('td'));
        if (cells.length === 0) return;

        let chosenCell = null;

        if (cells.length >= 7) {
          chosenCell = Math.random() < 0.75 ? cells[6] : cells[5];
        } else if (cells.length === 6) {
          chosenCell = Math.random() < 0.75 ? cells[5] : cells[4];
        } else if (cells.length === 5) {
          chosenCell = Math.random() < 0.75 ? cells[4] : cells[3];
        } else {
          const optionCells = cells.filter(td => td.querySelector('input, label, .ant-checkbox, .ant-radio, .ant-checkbox-wrapper, .ant-radio-wrapper'));
          if (optionCells.length >= 5) {
            chosenCell = Math.random() < 0.75 ? optionCells[optionCells.length - 1] : optionCells[optionCells.length - 2];
          } else if (optionCells.length > 0) {
            chosenCell = optionCells[optionCells.length - 1];
          }
        }

        if (chosenCell) {
          safeClickOption(chosenCell);
        }
      });

      const pick10 = Math.random() < 0.7;
      const targetRating = pick10 ? '10' : '9';
      const allFormItems = Array.from(document.querySelectorAll('.ant-form-item, .ant-card, div'));
      const scale10Item = allFormItems.find(el => {
        const t = (el.textContent || '').toLowerCase();
        return (t.includes('thang điểm từ 1') || t.includes('1 (rất kém)') || t.includes('đến 10')) &&
               el.querySelectorAll('.ant-radio-wrapper, .ant-checkbox-wrapper, input').length >= 8;
      });

      if (scale10Item) {
        const opts = Array.from(scale10Item.querySelectorAll('.ant-radio-wrapper, .ant-checkbox-wrapper, label'));
        const opt10 = opts.find(o => (o.textContent || '').trim() === '10');
        const opt9 = opts.find(o => (o.textContent || '').trim() === '9');
        const chosen = (pick10 && opt10) ? opt10 : (opt9 || opt10 || opts[opts.length - 1]);
        if (chosen) safeClickOption(chosen);
      } else {
        const opt = (pick10) ? (findOptionByExactText('10') || findOptionByExactText('9')) : (findOptionByExactText('9') || findOptionByExactText('10'));
        if (opt) safeClickOption(opt);
      }

      const g5 = findOptionByText([
        'thảo luận/giải đáp trực tiếp',
        'kết hợp: tự học',
        'học kết hợp',
        'hoàn toàn qua bài giảng'
      ]);
      if (g5) {
        safeClickOption(g5);
      }

      const textareas = document.querySelectorAll('textarea, input[type="text"]');
      textareas.forEach(field => {
        if (field.classList.contains('ant-pagination-options-quick-jumper')) return;
        const parent = field.closest('.ant-form-item') || field.parentElement;
        const parentText = (parent ? parent.textContent : '').toLowerCase();

        if (parentText.includes('hài lòng nhất')) {
          triggerTextInput(field, 'Bài giảng điện tử được thiết kế rất khoa học, video rõ nét, âm thanh chuẩn, bài tập tương tác sinh động giúp nắm bắt kiến thức hiệu quả.');
          filledCount++;
        } else if (parentText.includes('cải thiện nhất')) {
          triggerTextInput(field, 'Bài giảng hiện tại rất đầy đủ và chất lượng; mong Thầy/Cô tiếp tục phát huy và cập nhật thêm các bài tập tình huống thực tế.');
          filledCount++;
        } else if (parentText.includes('bổ sung')) {
        } else {
          const isRequired = parentText.includes('*') || field.hasAttribute('required') || (parent && parent.querySelector('.ant-form-item-required'));
          if (isRequired && !field.value.trim()) {
            triggerTextInput(field, 'Nội dung bài giảng được thiết kế rất khoa học, dễ tiếp thu; Thầy/Cô nhiệt tình giảng dạy và giải đáp thắc mắc cho sinh viên.');
            filledCount++;
          }
        }
      });

      allRows.forEach(tr => {
        if (tr.querySelector('th') || tr.closest('thead')) return;
        const inputs = Array.from(tr.querySelectorAll('input[type="checkbox"], input[type="radio"], input'));
        const hasChecked = inputs.some(i => i.checked) ||
                           tr.querySelector('.ant-checkbox-checked, .ant-radio-checked, .ant-checkbox-wrapper-checked, .ant-radio-wrapper-checked');
        if (!hasChecked) {
          const cells = Array.from(tr.querySelectorAll('td'));
          if (cells.length > 0) {
            safeClickOption(cells[cells.length - 1]);
          }
        }
      });

      document.querySelectorAll('.ant-form-item, [role="radiogroup"], .ant-radio-group').forEach(formItem => {
        const text = formItem.textContent || '';
        const isRequired = text.includes('*') || formItem.querySelector('.ant-form-item-required');
        if (!isRequired) return;

        const inputs = Array.from(formItem.querySelectorAll('input[type="radio"], input[type="checkbox"]'));
        const hasChecked = inputs.some(i => i.checked) ||
                           formItem.querySelector('.ant-radio-wrapper-checked, .ant-checkbox-wrapper-checked, .ant-radio-checked, .ant-checkbox-checked');
        if (!hasChecked && inputs.length > 0) {
          const target = inputs[inputs.length - 1];
          safeClickOption(target.closest('label, .ant-radio-wrapper, .ant-checkbox-wrapper') || target);
        }
      });

      if (filledCount > 0) {
        showToast(`⚡ Đã điền xong đầy đủ phiếu đánh giá (${savedYear}, 4-5⭐)! Hãy kiểm tra và bấm Gửi.`);
      } else {
        showToast('⚠️ Không tìm thấy bảng khảo sát trên trang hiện tại.');
      }

      return filledCount;
    }

    function injectSLinkHUD() {
      if (document.getElementById('ptit-slink-hud')) return;

      hudElement = document.createElement('div');
      hudElement.id = 'ptit-slink-hud';
      hudElement.style.cssText = [
        'position: fixed',
        'bottom: 85px',
        'right: 24px',
        'z-index: 2147483640',
        'font-family: system-ui, -apple-system, sans-serif',
        'transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
      ].join(';');

      renderHUDContent();
      (document.body || document.documentElement).appendChild(hudElement);
    }

    function renderHUDContent() {
      if (!hudElement) return;

      const currentYear = localStorage.getItem('ptit_slink_student_year') || 'Năm 3';

      if (isMinimized) {
        hudElement.innerHTML = `
          <div id="ptit-slink-hud-pill" style="
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: #ffffff;
            padding: 10px 14px;
            border-radius: 30px;
            box-shadow: 0 10px 25px -5px rgba(239, 68, 68, 0.5);
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 700;
            border: 1px solid rgba(255, 255, 255, 0.25);
            transition: transform 0.2s ease;
          ">
            <span>⚡ Điền Đánh Giá (${currentYear})</span>
          </div>
        `;
        const pill = hudElement.querySelector('#ptit-slink-hud-pill');
        pill.onmouseover = () => pill.style.transform = 'scale(1.05)';
        pill.onmouseout = () => pill.style.transform = 'scale(1)';
        pill.onclick = () => {
          isMinimized = false;
          renderHUDContent();
        };
      } else {
        hudElement.innerHTML = `
          <div style="
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 14px 16px;
            box-shadow: 0 15px 35px -5px rgba(0, 0, 0, 0.6);
            width: 260px;
            color: #f8fafc;
          ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="font-size: 16px;">⚡</span>
                <span style="font-size: 13px; font-weight: 700; color: #fff;">PTIT S-Link Auto-Fill</span>
              </div>
              <button id="ptit-slink-hud-close" style="
                background: none;
                border: none;
                color: #94a3b8;
                font-size: 14px;
                cursor: pointer;
                padding: 2px 6px;
                border-radius: 4px;
              " title="Thu nhỏ">✕</button>
            </div>
            
            <p style="font-size: 11px; color: #94a3b8; margin-bottom: 10px; line-height: 1.4;">
              Điền toàn bộ tiêu chí B–F với mức ngẫu nhiên <b>4 - 5⭐</b>.
            </p>

            <!-- Ô CHỌN NĂM SINH VIÊN -->
            <div style="margin-bottom: 12px; background: rgba(30, 41, 59, 0.7); padding: 8px 10px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.1);">
              <label for="ptit-slink-student-year" style="font-size: 11px; font-weight: 700; color: #cbd5e1; display: block; margin-bottom: 4px;">
                🎓 Bạn là sinh viên năm:
              </label>
              <select id="ptit-slink-student-year" style="
                width: 100%;
                background: #0f172a;
                color: #f8fafc;
                border: 1px solid #475569;
                border-radius: 6px;
                padding: 5px 8px;
                font-size: 12px;
                font-weight: 600;
                cursor: pointer;
                outline: none;
              ">
                <option value="Năm 1">Năm 1</option>
                <option value="Năm 2">Năm 2</option>
                <option value="Năm 3">Năm 3</option>
                <option value="Năm 4">Năm 4</option>
                <option value="Khác">Câu trả lời khác</option>
              </select>
            </div>

            <button id="ptit-slink-btn-autofill" style="
              width: 100%;
              background: linear-gradient(135deg, #ef4444, #dc2626);
              color: #ffffff;
              border: none;
              padding: 9px 12px;
              border-radius: 8px;
              font-size: 13px;
              font-weight: 700;
              cursor: pointer;
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 6px;
              box-shadow: 0 4px 14px rgba(239, 68, 68, 0.4);
              transition: all 0.15s ease;
            ">
              <span>⚡ Điền Nhanh Đánh Giá</span>
            </button>
          </div>
        `;

        const yearSelect = hudElement.querySelector('#ptit-slink-student-year');
        if (yearSelect) {
          yearSelect.value = currentYear;
          yearSelect.onchange = (e) => {
            localStorage.setItem('ptit_slink_student_year', e.target.value);
            showToast(`🎓 Đã ghi nhớ: ${e.target.value}`);
          };
        }

        const closeBtn = hudElement.querySelector('#ptit-slink-hud-close');
        closeBtn.onclick = () => {
          isMinimized = true;
          renderHUDContent();
        };

        const fillBtn = hudElement.querySelector('#ptit-slink-btn-autofill');
        fillBtn.onmouseover = () => fillBtn.style.transform = 'translateY(-1px)';
        fillBtn.onmouseout = () => fillBtn.style.transform = 'translateY(0)';
        fillBtn.onclick = (e) => {
          e.preventDefault();
          fillBtn.innerHTML = '<span>⏳ Đang điền...</span>';
          setTimeout(() => {
            runAutoFill();
            setTimeout(() => {
              runAutoFill();
            }, 300);
            fillBtn.innerHTML = `<span>✓ Đã điền xong!</span>`;
            setTimeout(() => {
              fillBtn.innerHTML = '<span>⚡ Điền Nhanh Đánh Giá</span>';
            }, 3000);
          }, 150);
        };
      }
    }

    function checkHUDVisibility() {
      if (isEvaluationPage()) {
        if (!hudElement) {
          injectSLinkHUD();
        } else {
          hudElement.style.display = 'block';
        }
      } else {
        if (hudElement) {
          hudElement.style.display = 'none';
        }
      }
    }

    window.addEventListener('hashchange', checkHUDVisibility);
    window.addEventListener('popstate', checkHUDVisibility);

    const origPushState = history.pushState;
    if (origPushState) {
      history.pushState = function () {
        origPushState.apply(this, arguments);
        setTimeout(checkHUDVisibility, 300);
      };
    }

    const origReplaceState = history.replaceState;
    if (origReplaceState) {
      history.replaceState = function () {
        origReplaceState.apply(this, arguments);
        setTimeout(checkHUDVisibility, 300);
      };
    }

    setInterval(checkHUDVisibility, 1500);

    const domObserver = new MutationObserver(() => {
      checkHUDVisibility();
    });

    if (document.body) {
      domObserver.observe(document.body, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        domObserver.observe(document.body, { childList: true, subtree: true });
        checkHUDVisibility();
      });
    }

    setTimeout(checkHUDVisibility, 500);
  }

  if (isLMS) {
    initLMSQuizAutoRunner();
  }

  function initLMSQuizAutoRunner() {
    let hudElement = null;
    let isMinimized = false;
    let loopInterval = null;
    let lastActionTime = 0;
    let lastHandledState = '';

    function normalizeText(text) {
      if (!text) return '';
      let str = text.toString().toLowerCase();
      str = str.replace(/^(câu|cau|question)\s*\d+[\s:.-]*/i, '');
      str = str.replace(/^\d+[\s:.-]+/, '');
      str = str.replace(/\((chọn|hãy chọn|chon)[^)]+\)/gi, '');
      str = str.replace(/chọn\s*(1|một|nhiều)\s*đáp\s*án/gi, '');
      str = str.replace(/chon\s*(1|mot|nhieu)\s*dap\s*an/gi, '');
      str = str.replace(/đánh\s*dấu\s*xem\s*lại/gi, '');
      str = str.replace(/danh\s*dau\s*xem\s*lai/gi, '');
      str = str.replace(/\d+\s*(điểm|diem)/gi, '');
      str = str.replace(/[\u2013\u2014\u2015\u2212]/g, ' ');
      str = str.replace(/[\u2018\u2019\u201A\u201B]/g, "'");
      str = str.replace(/[\u201C\u201D\u201E\u201F]/g, '"');
      str = str.replace(/[.,:;?!_~`*#^(){}\[\]\-\/\\]+/g, ' ');
      str = str.replace(/\s+/g, ' ').trim();
      return str;
    }

    function detectCourseContext() {
      const url = window.location.href;
      let courseCode = '';
      let semester = '';
      let lessonId = '';

      const courseMatch = url.match(/course-v1:PTIT\+([A-Za-z0-9_-]+)\+([0-9]+)/i);
      if (courseMatch) {
        courseCode = courseMatch[1].toUpperCase();
        semester = courseMatch[2];
      } else {
        const altMatch = url.match(/courses\/([A-Za-z0-9_+-]+)/);
        if (altMatch) {
          const parts = altMatch[1].split('+');
          if (parts.length >= 2) courseCode = parts[1].toUpperCase();
        }
      }

      const lessonMatch = url.match(/[?&]lessonId=([^&#]+)/);
      if (lessonMatch) {
        lessonId = decodeURIComponent(lessonMatch[1]);
      }

      let courseName = '';
      const headerEl = document.querySelector('.course-header, h1, [class*="courseTitle"], [class*="course-name"], [class*="CourseHeader"]');
      if (headerEl) {
        courseName = headerEl.innerText.trim();
      }

      let lessonName = '';
      const activeLessonEl = document.querySelector('.ant-tree-node-selected, [class*="lesson"][class*="active"], [class*="current"], [class*="item-active"]');
      if (activeLessonEl) {
        lessonName = activeLessonEl.innerText.trim().replace(/\n+/g, ' ');
      }

      return { courseCode, semester, lessonId, courseName, lessonName };
    }

    function getStoredQuizDB() {
      try {
        const raw = localStorage.getItem('ptit_lms_quiz_db');
        if (!raw) return {};
        const parsed = JSON.parse(raw);
        const db = {};
        if (Array.isArray(parsed)) {
          parsed.forEach(item => {
            const q = item.question || item.q || item.cau_hoi || item.title || '';
            const a = item.answer || item.a || item.dap_an || item.correct || '';
            if (q && a) {
              db[normalizeText(q)] = String(a).trim();
            }
          });
        } else if (typeof parsed === 'object') {
          for (const [k, v] of Object.entries(parsed)) {
            if (k && v && typeof v !== 'object') {
              db[normalizeText(k)] = String(v).trim();
            }
          }
        }
        return db;
      } catch (e) {
        console.error('[PTIT LMS Quiz] Lỗi đọc quiz DB:', e);
        return {};
      }
    }

    function mergeQuizDataIntoDB(parsed, sourceName = '') {
      let currentDB = {};
      try {
        currentDB = JSON.parse(localStorage.getItem('ptit_lms_quiz_db') || '{}');
      } catch (e) {
        currentDB = {};
      }

      let added = 0;
      let subjectCode = '';
      let subjectName = '';

      if (parsed && typeof parsed === 'object') {
        if (parsed.subject_code) subjectCode = parsed.subject_code.toUpperCase();
        if (parsed.subject_name) subjectName = parsed.subject_name;

        if (Array.isArray(parsed.quizzes)) {
          parsed.quizzes.forEach(quiz => {
            if (Array.isArray(quiz.questions)) {
              quiz.questions.forEach(item => {
                const q = item.question || item.q || item.cau_hoi || '';
                const a = item.answer || item.a || item.dap_an || '';
                if (q && a) {
                  currentDB[normalizeText(q)] = String(a).trim();
                  added++;
                }
              });
            }
          });
        } else if (Array.isArray(parsed.questions)) {
          parsed.questions.forEach(item => {
            const q = item.question || item.q || item.cau_hoi || '';
            const a = item.answer || item.a || item.dap_an || '';
            if (q && a) {
              currentDB[normalizeText(q)] = String(a).trim();
              added++;
            }
          });
        } else if (Array.isArray(parsed)) {
          parsed.forEach(item => {
            const q = item.question || item.q || item.cau_hoi || item.title || '';
            const a = item.answer || item.a || item.dap_an || item.correct || '';
            if (q && a) {
              currentDB[normalizeText(q)] = String(a).trim();
              added++;
            }
          });
        } else {
          for (const [k, v] of Object.entries(parsed)) {
            if (k && v && typeof v !== 'object') {
              currentDB[normalizeText(k)] = String(v).trim();
              added++;
            }
          }
        }
      }

      localStorage.setItem('ptit_lms_quiz_db', JSON.stringify(currentDB));

      if (subjectCode) {
        try {
          let subjects = JSON.parse(localStorage.getItem('ptit_lms_quiz_subjects') || '{}');
          subjects[subjectCode] = {
            name: subjectName || subjectCode,
            count: added,
            updated_at: Date.now()
          };
          localStorage.setItem('ptit_lms_quiz_subjects', JSON.stringify(subjects));
        } catch (e) {}
      }

      window.dispatchEvent(new CustomEvent('ptit_storage_updated'));
      return added;
    }

    async function syncFromGitHub(courseCode) {
      if (!courseCode) {
        const ctx = detectCourseContext();
        courseCode = ctx.courseCode;
      }

      if (!courseCode) {
        courseCode = prompt('Nhập mã môn học cần tải đáp án (Ví dụ: MUL12117):', 'MUL12117');
        if (!courseCode) return;
        courseCode = courseCode.trim().toUpperCase();
      }

      const GITHUB_REPO = 'GLGT67/PTIT-LMS-EXTENSION-UNLOCK';
      const rawUrl = `https://raw.githubusercontent.com/${GITHUB_REPO}/main/database/${courseCode}.json`;

      showToast(`🌐 Đang tải đáp án môn ${courseCode} từ GitHub...`);

      try {
        const resp = await fetch(rawUrl, { cache: 'no-cache' });
        if (!resp.ok) {
          if (resp.status === 404) {
            showToast(`⚠️ Chưa có file đáp án môn ${courseCode} trên GitHub repo của GLGT67.`);
          } else {
            showToast(`❌ Lỗi kết nối GitHub (HTTP ${resp.status})`);
          }
          return false;
        }
        const data = await resp.json();
        const count = mergeQuizDataIntoDB(data, `${courseCode}.json`);
        showToast(`✓ Đã nạp thành công ${count} câu hỏi môn ${courseCode} từ GitHub!`);
        renderHUDContent();
        return true;
      } catch (err) {
        showToast(`❌ Không thể tải: ${err.message}`);
        return false;
      }
    }

    function importFromLocalFile(file) {
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          const count = mergeQuizDataIntoDB(data, file.name);
          showToast(`✓ Đã nạp thành công ${count} câu hỏi từ [${file.name}]!`);
          renderHUDContent();
        } catch (err) {
          alert('Tệp tin không đúng định dạng JSON hợp lệ: ' + err.message);
        }
      };
      reader.readAsText(file);
    }

    function findAnswerInDB(rawQuestion, db) {
      let normQ = normalizeText(rawQuestion);
      if (!normQ) return null;

      normQ = normQ
        .replace(/^(câu|cau)\s*\d+[:.]?/, '')
        .replace(/^(chọn|chon)\s*\d+\s*(đáp|dap)\s*án/, '')
        .replace(/^(đánh|danh)\s*(dấu|dau)\s*xem\s*lại/, '')
        .trim();

      if (db[normQ]) return db[normQ];

      for (const [key, ans] of Object.entries(db)) {
        if (key.length >= 8 && normQ.length >= 8) {
          if (normQ.includes(key) || key.includes(normQ)) {
            return ans;
          }
        }
      }

      const qWords = new Set(normQ.split(' ').filter(w => w.length > 2));
      if (qWords.size < 3) return null;

      let bestMatch = null;
      let maxScore = 0;

      for (const [key, ans] of Object.entries(db)) {
        const kWords = new Set(key.split(' ').filter(w => w.length > 2));
        if (kWords.size < 3) continue;

        let common = 0;
        kWords.forEach(w => {
          if (qWords.has(w)) common++;
        });

        const overlap = common / kWords.size;
        const jaccard = common / new Set([...qWords, ...kWords]).size;
        const score = Math.max(overlap, jaccard);

        if (score > maxScore && (score >= 0.55 || (overlap >= 0.7 && common >= 3))) {
          maxScore = score;
          bestMatch = ans;
        }
      }

      return bestMatch;
    }

    function getQuestionCards() {
      const direct = Array.from(document.querySelectorAll('.question-item, .quiz-question, [class*="QuestionCard"], [class*="question-card"]'));
      if (direct.length > 0) return direct;

      const allDivs = Array.from(document.querySelectorAll('div, section, article'));
      const matched = [];
      allDivs.forEach(el => {
        if (el.children.length >= 1 && el.querySelectorAll('input, [role="radio"], .ant-radio-wrapper').length > 0) {
          const text = (el.innerText || el.textContent || '').slice(0, 150);
          if (/câu\s*\d+/i.test(text)) {
            matched.push(el);
          }
        }
      });

      if (matched.length > 0) {
        const leaves = matched.filter(m => !matched.some(other => other !== m && m.contains(other)));
        if (leaves.length > 0) return leaves;
      }

      const groups = Array.from(document.querySelectorAll('.ant-radio-group, [role="radiogroup"]'));
      if (groups.length > 0) {
        return groups.map(g => {
          let curr = g.parentElement;
          while (curr && curr !== document.body) {
            const txt = (curr.innerText || curr.textContent || '').slice(0, 200);
            if (/câu\s*\d+/i.test(txt)) {
              return curr;
            }
            curr = curr.parentElement;
          }
          return g.closest('.ant-card, [class*="card"]') || g.parentElement || g;
        });
      }

      return [];
    }

    function extractQuestionText(card) {
      if (!card) return '';

      const titleEl = card.querySelector('.question-title, .question-text, .quiz-title, [class*="questionTitle"], [class*="question-title"], [class*="questionContent"], [class*="question-content"], .ant-form-item-label');
      if (titleEl) {
        let tText = (titleEl.innerText || titleEl.textContent || '')
          .replace(/câu\s*\d+[:.]?/gi, '')
          .replace(/chọn\s*\d+\s*đáp\s*án/gi, '')
          .replace(/đánh\s*dấu\s*xem\s*lại/gi, '')
          .replace(/điểm[:\s]*\d+([,.]\d+)?/gi, '')
          .replace(/xem\s*lại/gi, '')
          .replace(/\s+/g, ' ')
          .trim();
        if (tText && tText.length >= 6) return tText;
      }

      const clone = card.cloneNode(true);
      clone.querySelectorAll('.ant-radio-group, [role="radiogroup"], .ant-checkbox-group, .ant-radio-wrapper, .ant-checkbox-wrapper, input[type="radio"], input[type="checkbox"], button, svg').forEach(el => el.remove());
      
      let rawText = (clone.innerText || clone.textContent || '').trim();
      rawText = rawText
        .replace(/câu\s*\d+[:.]?/gi, '')
        .replace(/chọn\s*\d+\s*đáp\s*án/gi, '')
        .replace(/đánh\s*dấu\s*xem\s*lại/gi, '')
        .replace(/điểm[:\s]*\d+([,.]\d+)?/gi, '')
        .replace(/xem\s*lại/gi, '')
        .replace(/\s+/g, ' ')
        .trim();

      return rawText;
    }

    function checkQuizCoverage(cards, db) {
      const hasVideo = !!document.querySelector('video');
      if (!cards || cards.length === 0) {
        return {
          type: hasVideo ? 'video' : 'page',
          total: 0,
          matched: 0,
          text: hasVideo ? '🎬 Video bài giảng' : '📄 Nội dung bài học',
          color: hasVideo ? '#38bdf8' : '#94a3b8'
        };
      }

      let matched = 0;
      cards.forEach(card => {
        const qText = extractQuestionText(card);
        if (findAnswerInDB(qText, db)) matched++;
      });

      const total = cards.length;
      if (matched === total && total > 0) {
        return {
          type: 'full',
          total,
          matched,
          text: `🟢 Đủ ${matched}/${total} đáp án`,
          color: '#10b981'
        };
      } else if (matched > 0) {
        return {
          type: 'partial',
          total,
          matched,
          text: `🟡 Khớp ${matched}/${total} đáp án`,
          color: '#f59e0b'
        };
      } else {
        return {
          type: 'none',
          total,
          matched: 0,
          text: `🔴 Chưa có đáp án (0/${total})`,
          color: '#ef4444'
        };
      }
    }

    function safeClickChoice(choiceElement) {
      if (!choiceElement) return false;

      let target = choiceElement.querySelector('label, .ant-radio-wrapper, .ant-radio, input') || choiceElement;
      const input = target.tagName === 'INPUT' ? target : target.querySelector('input');

      const mouseOpts = { bubbles: true, cancelable: true, view: window };
      target.dispatchEvent(new MouseEvent('mousedown', mouseOpts));
      target.dispatchEvent(new MouseEvent('mouseup', mouseOpts));
      target.click();

      if (input && !input.checked) {
        input.checked = true;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }

      return true;
    }

    function solveQuizOnPage() {
      const db = getStoredQuizDB();
      const dbSize = Object.keys(db).length;

      if (dbSize === 0) {
        showToast('⚠️ Kho đáp án đang trống! Hãy nạp file JSON hoặc bấm Tải từ GitHub.');
        return { answered: 0, total: 0, dbEmpty: true };
      }

      const cards = getQuestionCards();
      if (cards.length === 0) {
        showToast('⚠️ Không tìm thấy câu hỏi trắc nghiệm nào trên trang.');
        return { answered: 0, total: 0 };
      }

      let answeredCount = 0;

      cards.forEach((card, index) => {
        const qText = extractQuestionText(card);
        const expectedAnswer = findAnswerInDB(qText, db);

        if (!expectedAnswer) {
          console.log(`[PTIT LMS Quiz] Chưa có đáp án cho Câu ${index + 1}:`, qText.slice(0, 60));
          return;
        }

        const normExpected = normalizeText(expectedAnswer);

        let choices = Array.from(card.querySelectorAll('.ant-radio-wrapper, .ant-radio-button-wrapper, [role="radio"], .ant-checkbox-wrapper, [role="checkbox"]'));
        if (choices.length === 0) {
          choices = Array.from(card.querySelectorAll('input[type="radio"], input[type="checkbox"]')).map(i => i.closest('label') || i.parentElement || i);
        }
        if (choices.length === 0) {
          choices = Array.from(card.querySelectorAll('label, div[class*="option-item"]'));
        }

        choices = choices.filter(c => !choices.some(other => other !== c && c.contains(other)));

        let matchedChoice = null;

        for (const choice of choices) {
          let choiceText = choice.innerText || choice.textContent || '';
          let normChoice = normalizeText(choiceText).replace(/^[abcd][\s.)-]+/, '').trim();

          if (normChoice && (normChoice === normExpected || normChoice.includes(normExpected) || normExpected.includes(normChoice))) {
            matchedChoice = choice;
            break;
          }
        }

        if (!matchedChoice) {
          const expWords = new Set(normExpected.split(' ').filter(w => w.length > 2));
          let bestChoiceScore = 0;

          for (const choice of choices) {
            let choiceText = choice.innerText || choice.textContent || '';
            let normChoice = normalizeText(choiceText).replace(/^[abcd][\s.)-]+/, '').trim();
            const cWords = new Set(normChoice.split(' ').filter(w => w.length > 2));
            if (cWords.size === 0) continue;

            let common = 0;
            expWords.forEach(w => { if (cWords.has(w)) common++; });
            const score = common / Math.max(expWords.size, 1);

            if (score > bestChoiceScore && score >= 0.5) {
              bestChoiceScore = score;
              matchedChoice = choice;
            }
          }
        }

        if (matchedChoice) {
          safeClickChoice(matchedChoice);
          answeredCount++;
        }
      });

      showToast(`🎯 Đã giải xong ${answeredCount}/${cards.length} câu hỏi theo Database!`);
      renderHUDContent();
      return { answered: answeredCount, total: cards.length };
    }

    function submitQuiz() {
      const submitBtns = Array.from(document.querySelectorAll('button, a')).filter(el => {
        const t = (el.innerText || el.textContent || '').trim();
        return t === 'Nộp bài' || t.includes('Nộp bài');
      });

      if (submitBtns.length === 0) {
        showToast('⚠️ Không tìm thấy nút Nộp bài trên giao diện.');
        return false;
      }

      const submitBtn = submitBtns[0];
      submitBtn.click();
      showToast('⏳ Đang bấm Nộp bài, chờ xác nhận modal...');

      setTimeout(() => {
        const modal = document.querySelector('.ant-modal, [role="dialog"], .ant-modal-content');
        if (modal) {
          const confirmBtns = Array.from(modal.querySelectorAll('button')).filter(b => {
            const t = (b.innerText || b.textContent || '').trim();
            return t === 'Nộp bài' || t.includes('Nộp bài') || t.includes('Xác nhận') || t.includes('Đồng ý');
          });
          if (confirmBtns.length > 0) {
            confirmBtns[confirmBtns.length - 1].click();
            showToast('🚀 Đã xác nhận Nộp bài thành công!');
            return;
          }
        }

        const fallbackBtns = Array.from(document.querySelectorAll('.ant-btn-primary, .ant-btn-dangerous')).filter(b => {
          const t = (b.innerText || b.textContent || '').trim();
          return t === 'Nộp bài' || t.includes('Nộp bài') || t.includes('Xác nhận');
        });
        if (fallbackBtns.length > 0) {
          fallbackBtns[fallbackBtns.length - 1].click();
          showToast('🚀 Đã xác nhận Nộp bài thành công!');
        }
      }, 700);

      return true;
    }

    function skipCurrentVideo() {
      const video = document.querySelector('video');
      if (video && video.duration && video.duration > 2) {
        video.currentTime = video.duration - 1;
        video.play().catch(() => {});
        showToast('⏩ Đã nhảy tới cuối video!');
        return true;
      }
      return false;
    }

    function runAutoLoopTick() {
      const isAuto = localStorage.getItem('ptit_lms_autoloop') === 'true';
      if (!isAuto) return;

      const now = Date.now();
      if (now - lastActionTime < 2500) return;

      const video = document.querySelector('video');
      if (video && video.duration && !video.ended) {
        if (video.currentTime < video.duration - 2) {
          video.currentTime = video.duration - 1.5;
          video.play().catch(() => {});
          lastActionTime = now;
          showToast('⚡ Auto-Loop: Tua hoàn thành video...');
          return;
        }
      }

      const startQuizBtns = Array.from(document.querySelectorAll('button, a')).filter(el => {
        const t = (el.innerText || el.textContent || '').trim();
        return t.includes('Bắt đầu làm bài') || t.includes('Tiếp tục làm bài') || t.includes('Làm lại bài');
      });

      if (startQuizBtns.length > 0) {
        if (lastHandledState !== 'quiz_start') {
          lastHandledState = 'quiz_start';
          lastActionTime = now;
          showToast('🚀 Auto-Loop: Bắt đầu làm bài trắc nghiệm...');
          setTimeout(() => {
            startQuizBtns[0].click();
          }, 1000);
          return;
        }
      }

      const cards = getQuestionCards();
      if (cards.length > 0) {
        if (lastHandledState !== 'quiz_in_progress') {
          lastHandledState = 'quiz_in_progress';
          lastActionTime = now;
          showToast('📝 Auto-Loop: Đang giải bài trắc nghiệm...');
          setTimeout(() => {
            const res = solveQuizOnPage();
            if (res.answered > 0 || !res.dbEmpty) {
              setTimeout(() => {
                showToast('🚀 Auto-Loop: Nộp bài trắc nghiệm...');
                submitQuiz();
                lastActionTime = Date.now();
              }, 2000);
            }
          }, 1000);
          return;
        }
      }

      const returnCourseBtns = Array.from(document.querySelectorAll('button, a')).filter(el => {
        const t = (el.innerText || el.textContent || '').trim();
        return t.includes('Trở lại khóa học') || t.includes('Về khóa học');
      });

      if (returnCourseBtns.length > 0) {
        if (lastHandledState !== 'quiz_result') {
          lastHandledState = 'quiz_result';
          lastActionTime = now;
          showToast('↩️ Auto-Loop: Quay lại danh mục bài học...');
          setTimeout(() => {
            returnCourseBtns[0].click();
          }, 1500);
          return;
        }
      }

      const lessonItems = Array.from(document.querySelectorAll('[class*="lesson"], [class*="item"], .ant-tree-node-content-wrapper, [role="treeitem"], div[class*="chapter"] li'));
      if (lessonItems.length > 0) {
        const nextLesson = lessonItems.find(el => {
          const hasCheck = el.querySelector('svg[class*="check"], [class*="success"], [class*="completed"], .anticon-check-circle, .anticon-check');
          const isHeader = el.querySelector('[class*="header"], [class*="title"]') && !el.querySelector('a, [role="button"]');
          return !hasCheck && !isHeader;
        });

        if (nextLesson && lastHandledState !== 'moving_to_next_lesson') {
          lastHandledState = 'moving_to_next_lesson';
          lastActionTime = now;
          showToast('📖 Auto-Loop: Mở bài học tiếp theo...');
          setTimeout(() => {
            const clickable = nextLesson.querySelector('a, button, [role="button"]') || nextLesson;
            clickable.click();
            setTimeout(() => { lastHandledState = ''; }, 3000);
          }, 1500);
          return;
        }
      }

      const nextBtn = Array.from(document.querySelectorAll('button, a')).find(el => {
        const t = (el.innerText || el.textContent || '').trim();
        return t === 'Bài tiếp theo' || t === 'Tiếp tục' || t.includes('Bài tiếp theo');
      });

      if (nextBtn && lastHandledState !== 'clicked_next_btn') {
        lastHandledState = 'clicked_next_btn';
        lastActionTime = now;
        showToast('⏭ Auto-Loop: Chuyển sang bài tiếp theo...');
        setTimeout(() => {
          nextBtn.click();
          setTimeout(() => { lastHandledState = ''; }, 3000);
        }, 1500);
        return;
      }
    }

    function promptFastJSONImport() {
      const modalId = 'ptit-lms-json-modal';
      let modal = document.getElementById(modalId);
      if (modal) modal.remove();

      modal = document.createElement('div');
      modal.id = modalId;
      modal.style.cssText = [
        'position: fixed',
        'top: 0',
        'left: 0',
        'width: 100vw',
        'height: 100vh',
        'background: rgba(15, 23, 42, 0.75)',
        'backdrop-filter: blur(8px)',
        'z-index: 2147483647',
        'display: flex',
        'align-items: center',
        'justify-content: center',
        'font-family: system-ui, -apple-system, sans-serif'
      ].join(';');

      modal.innerHTML = `
        <div style="
          background: #0f172a;
          border: 1px solid rgba(56, 189, 248, 0.4);
          border-radius: 12px;
          padding: 20px;
          width: 480px;
          max-width: 90vw;
          box-shadow: 0 20px 40px rgba(0,0,0,0.8);
          color: #f8fafc;
        ">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <h3 style="font-size: 16px; font-weight: 700; color: #38bdf8; display: flex; align-items: center; gap: 8px;">
              <span>📋</span> Nạp Kho Đáp Án (JSON)
            </h3>
            <button id="ptit-lms-modal-close" style="background: none; border: none; color: #94a3b8; font-size: 16px; cursor: pointer;">✕</button>
          </div>
          <p style="font-size: 12px; color: #94a3b8; margin-bottom: 10px; line-height: 1.4;">
            Dán mã JSON câu hỏi - đáp án hoặc chọn tệp .json từ máy tính:
          </p>
          <textarea id="ptit-lms-modal-textarea" rows="6" placeholder='{"Câu hỏi...": "Đáp án đúng..."}' style="
            width: 100%;
            background: #1e293b;
            color: #f8fafc;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 10px;
            font-size: 12px;
            font-family: monospace;
            box-sizing: border-box;
            outline: none;
            resize: vertical;
            margin-bottom: 12px;
          "></textarea>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <label style="
              background: rgba(255,255,255,0.08);
              color: #38bdf8;
              border: 1px solid rgba(56, 189, 248, 0.3);
              padding: 7px 12px;
              border-radius: 6px;
              font-size: 12px;
              font-weight: 600;
              cursor: pointer;
            ">
              📁 Chọn file .json
              <input type="file" id="ptit-lms-modal-file" accept=".json,application/json" style="display: none;">
            </label>
            <div style="display: flex; gap: 8px;">
              <button id="ptit-lms-modal-cancel" style="
                background: #334155;
                color: #f8fafc;
                border: none;
                padding: 7px 14px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 600;
                cursor: pointer;
              ">Hủy</button>
              <button id="ptit-lms-modal-save" style="
                background: linear-gradient(135deg, #0284c7, #0369a1);
                color: #ffffff;
                border: none;
                padding: 7px 16px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 700;
                cursor: pointer;
              ">💾 Lưu Đáp Án</button>
            </div>
          </div>
        </div>
      `;

      document.body.appendChild(modal);

      const closeModal = () => modal.remove();
      modal.querySelector('#ptit-lms-modal-close').onclick = closeModal;
      modal.querySelector('#ptit-lms-modal-cancel').onclick = closeModal;

      const fileInput = modal.querySelector('#ptit-lms-modal-file');
      if (fileInput) {
        fileInput.onchange = (e) => {
          if (e.target.files && e.target.files[0]) {
            importFromLocalFile(e.target.files[0]);
            closeModal();
          }
        };
      }

      modal.querySelector('#ptit-lms-modal-save').onclick = () => {
        const text = modal.querySelector('#ptit-lms-modal-textarea').value.trim();
        if (!text) return;
        try {
          const parsed = JSON.parse(text);
          const added = mergeQuizDataIntoDB(parsed, 'Dán trực tiếp');
          showToast(`✓ Đã nạp thành công ${added} câu hỏi vào kho!`);
          closeModal();
          renderHUDContent();
        } catch (err) {
          alert('Mã JSON không hợp lệ! Vui lòng kiểm tra lại: ' + err.message);
        }
      };
    }

    function exportCurrentQuizToJSON() {
      const cards = getQuestionCards();
      if (!cards || cards.length === 0) {
        showToast('⚠️ Không tìm thấy câu hỏi trắc nghiệm nào trên trang!');
        return;
      }

      const ctx = detectCourseContext();
      const courseCode = ctx.courseCode || 'SKD1101';
      const lessonName = ctx.lessonName || document.title.split('-')[0].trim() || 'Bài tập trắc nghiệm';

      const extracted = [];

      cards.forEach((card, index) => {
        let qText = extractQuestionText(card);

        let choices = Array.from(card.querySelectorAll('.ant-radio-wrapper, .ant-radio-button-wrapper, .ant-checkbox-wrapper, [role="radio"]'));
        if (choices.length === 0) {
          choices = Array.from(card.querySelectorAll('input[type="radio"], input[type="checkbox"]')).map(i => i.closest('label') || i.parentElement || i);
        }
        if (choices.length === 0) {
          choices = Array.from(card.querySelectorAll('label, div[class*="option"], div[class*="choice"]'));
        }
        choices = choices.filter(c => !choices.some(other => other !== c && c.contains(other)));

        const options = [];
        let detectedAnswer = '';

        choices.forEach(ch => {
          let rawText = (ch.innerText || ch.textContent || '').trim();
          let cleanText = rawText.replace(/^[A-Da-d][\s.)-]+/, '').trim();
          if (cleanText) options.push(cleanText);

          const isGreen = ch.classList.contains('ant-radio-wrapper-checked') ||
                          ch.querySelector('.ant-radio-checked, input:checked') ||
                          /success|correct|true/i.test(ch.className) ||
                          (ch.style.color && ch.style.color.includes('green')) ||
                          (ch.style.borderColor && ch.style.borderColor.includes('green'));
          if (isGreen && !detectedAnswer && cleanText) {
            detectedAnswer = cleanText;
          }
        });

        if (!qText) {
          let fallback = (card.innerText || card.textContent || '')
            .replace(/câu\s*\d+[:.]?/gi, '')
            .replace(/chọn\s*\d+\s*đáp\s*án/gi, '')
            .replace(/đánh\s*dấu\s*xem\s*lại/gi, '');
          options.forEach(opt => {
            if (opt) fallback = fallback.replace(opt, '');
          });
          qText = fallback.replace(/\s+/g, ' ').trim();
        }

        if (!qText && options.length === 0) return;

        extracted.push({
          question: qText || `Câu ${index + 1}`,
          answer: detectedAnswer || (options[0] || ''),
          options: options.length > 0 ? options : ['A', 'B', 'C', 'D']
        });
      });

      const exportData = {
        subject_code: courseCode,
        subject_name: document.title.split('-')[0].trim() || courseCode,
        version: '1.0',
        updated_at: new Date().toISOString().slice(0, 10),
        author: 'PTIT_LMS_Harvester',
        total_questions: extracted.length,
        quizzes: [
          {
            lesson_name: lessonName,
            questions: extracted
          }
        ]
      };

      const jsonStr = JSON.stringify(exportData, null, 2);

      try {
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${courseCode}_scraped_${Date.now().toString().slice(-4)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      } catch (e) {}

      try {
        navigator.clipboard.writeText(jsonStr);
      } catch (e) {}

      showToast(`✓ Đã trích xuất & tải về ${extracted.length} câu hỏi môn ${courseCode}!`);
    }

    function injectLMSHUD() {
      if (document.getElementById('ptit-lms-hud')) return;

      hudElement = document.createElement('div');
      hudElement.id = 'ptit-lms-hud';
      hudElement.style.cssText = [
        'position: fixed',
        'bottom: 85px',
        'right: 24px',
        'z-index: 2147483640',
        'font-family: system-ui, -apple-system, sans-serif',
        'transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
      ].join(';');

      hudElement.ondragover = (e) => {
        e.preventDefault();
        hudElement.style.transform = 'scale(1.03)';
      };
      hudElement.ondragleave = (e) => {
        e.preventDefault();
        hudElement.style.transform = 'scale(1)';
      };
      hudElement.ondrop = (e) => {
        e.preventDefault();
        hudElement.style.transform = 'scale(1)';
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
          const file = e.dataTransfer.files[0];
          if (file.name.endsWith('.json')) {
            importFromLocalFile(file);
          } else {
            showToast('⚠️ Vui lòng thả tệp định dạng .json!');
          }
        }
      };

      renderHUDContent();
      (document.body || document.documentElement).appendChild(hudElement);
    }

    function renderHUDContent() {
      if (!hudElement) return;

      const isAuto = localStorage.getItem('ptit_lms_autoloop') === 'true';
      const ctx = detectCourseContext();
      const db = getStoredQuizDB();
      const dbCount = Object.keys(db).length;
      const cards = getQuestionCards();
      const coverage = checkQuizCoverage(cards, db);

      const courseBadge = ctx.courseCode ? ctx.courseCode : 'LMS';

      if (isMinimized) {
        hudElement.innerHTML = `
          <div id="ptit-lms-hud-pill" style="
            background: linear-gradient(135deg, ${isAuto ? '#059669' : '#0284c7'}, ${isAuto ? '#10b981' : '#0369a1'});
            color: #ffffff;
            padding: 9px 14px;
            border-radius: 30px;
            box-shadow: 0 10px 25px -5px rgba(2, 132, 199, 0.5);
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 700;
            border: 1px solid rgba(255, 255, 255, 0.25);
            transition: transform 0.2s ease;
          ">
            <span>⚡ ${courseBadge}: ${coverage.text} (${isAuto ? 'Loop: BẬT' : 'Loop: TẮT'})</span>
          </div>
        `;
        const pill = hudElement.querySelector('#ptit-lms-hud-pill');
        pill.onmouseover = () => pill.style.transform = 'scale(1.05)';
        pill.onmouseout = () => pill.style.transform = 'scale(1)';
        pill.onclick = () => {
          isMinimized = false;
          renderHUDContent();
        };
      } else {
        hudElement.innerHTML = `
          <div style="
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(56, 189, 248, 0.25);
            border-radius: 12px;
            padding: 14px 16px;
            box-shadow: 0 15px 35px -5px rgba(0, 0, 0, 0.6);
            width: 285px;
            color: #f8fafc;
          ">
            <!-- HEADER -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="font-size: 16px;">⚡</span>
                <span style="font-size: 13px; font-weight: 700; color: #38bdf8;">PTIT LMS Extension</span>
              </div>
              <button id="ptit-lms-hud-close" style="
                background: none;
                border: none;
                color: #94a3b8;
                font-size: 14px;
                cursor: pointer;
                padding: 2px 6px;
                border-radius: 4px;
              " title="Thu nhỏ">✕</button>
            </div>

            <!-- NHẬN DIỆN MÔN HỌC & BÀI HỌC -->
            <div style="margin-bottom: 8px; background: rgba(30, 41, 59, 0.85); padding: 8px 10px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.08); font-size: 11px;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: #94a3b8;">🎓 Môn học:</span>
                <b style="color: #38bdf8;">${ctx.courseCode || 'Chưa nhận diện'}</b>
              </div>
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="color: #94a3b8;">📊 Trạng thái:</span>
                <b style="color: ${coverage.color};">${coverage.text}</b>
              </div>
            </div>

            <!-- CHẾ ĐỘ AUTO-LOOP -->
            <div style="margin-bottom: 8px; background: rgba(30, 41, 59, 0.6); padding: 6px 10px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.06); display: flex; align-items: center; justify-content: space-between;">
              <span style="font-size: 11px; font-weight: 600;">▶ Auto-Loop:</span>
              <button id="ptit-lms-hud-toggle-loop" style="
                background: ${isAuto ? '#10b981' : '#475569'};
                color: #ffffff;
                border: none;
                padding: 3px 8px;
                border-radius: 10px;
                font-size: 10px;
                font-weight: 700;
                cursor: pointer;
                transition: background 0.2s;
              ">${isAuto ? '🟢 ĐANG BẬT' : '⚪ ĐANG TẮT'}</button>
            </div>

            <!-- NẠP ĐÁP ÁN: GITHUB & FILE LOCAL -->
            <div style="margin-bottom: 8px; padding-top: 6px; border-top: 1px dashed rgba(255,255,255,0.1); display: flex; flex-direction: column; gap: 5px;">
              <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #94a3b8;">
                <span>📚 Kho: <b style="color: #38bdf8;">${dbCount}</b> câu</span>
                <button id="ptit-lms-hud-paste-btn" style="background: none; border: none; color: #94a3b8; font-size: 10px; cursor: pointer; text-decoration: underline;">Dán text JSON</button>
              </div>

              <!-- NÚT ĐỒNG BỘ GITHUB -->
              <button id="ptit-lms-hud-sync-github" style="
                width: 100%;
                background: linear-gradient(135deg, #1e293b, #0f172a);
                color: #38bdf8;
                border: 1px solid rgba(56, 189, 248, 0.4);
                padding: 6px 10px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 700;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                transition: all 0.2s ease;
              ">
                <span>🌐 Tải đáp án từ GitHub (${ctx.courseCode || 'Môn này'})</span>
              </button>

              <!-- NÚT CHỌN FILE LOCAL -->
              <label style="
                width: 100%;
                background: rgba(255, 255, 255, 0.06);
                color: #cbd5e1;
                border: 1px dashed rgba(255, 255, 255, 0.2);
                padding: 6px 10px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                box-sizing: border-box;
              ">
                <span>📁 Chọn file JSON (hoặc kéo thả)</span>
                <input type="file" id="ptit-lms-hud-file-input" accept=".json,application/json" style="display: none;">
              </label>
            </div>

            <!-- NÚT THAO TÁC NHANH -->
            <div style="display: flex; flex-direction: column; gap: 5px; padding-top: 6px; border-top: 1px dashed rgba(255,255,255,0.1);">
              <button id="ptit-lms-hud-solve-btn" style="
                width: 100%;
                background: linear-gradient(135deg, #0284c7, #0369a1);
                color: #ffffff;
                border: none;
                padding: 7px 12px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 700;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
              ">
                <span>🎯 Điền Đáp Án Ngay</span>
              </button>

              <button id="ptit-lms-hud-submit-btn" style="
                width: 100%;
                background: linear-gradient(135deg, #ef4444, #dc2626);
                color: #ffffff;
                border: none;
                padding: 7px 12px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 700;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                box-shadow: 0 4px 12px rgba(239, 68, 68, 0.35);
              ">
                <span>🚀 Điền & Nộp Luôn</span>
              </button>

              <div style="display: flex; gap: 6px;">
                <button id="ptit-lms-hud-skip-vid" style="
                  flex: 1;
                  background: rgba(255, 255, 255, 0.06);
                  color: #94a3b8;
                  border: 1px solid rgba(255, 255, 255, 0.12);
                  padding: 5px 8px;
                  border-radius: 6px;
                  font-size: 11px;
                  font-weight: 600;
                  cursor: pointer;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 4px;
                ">
                  <span>⏩ Skip Video</span>
                </button>
                <button id="ptit-lms-hud-speed-2x" title="Tốc độ 2.0x" style="
                  background: rgba(255, 255, 255, 0.06);
                  color: #38bdf8;
                  border: 1px solid rgba(255, 255, 255, 0.12);
                  padding: 5px 8px;
                  border-radius: 6px;
                  font-size: 11px;
                  font-weight: 600;
                  cursor: pointer;
                ">⚡ 2x</button>
                <button id="ptit-lms-hud-speed-5x" title="Tốc độ 5.0x" style="
                  background: rgba(255, 255, 255, 0.06);
                  color: #f59e0b;
                  border: 1px solid rgba(255, 255, 255, 0.12);
                  padding: 5px 8px;
                  border-radius: 6px;
                  font-size: 11px;
                  font-weight: 600;
                  cursor: pointer;
                ">🚀 5x</button>
              </div>

              ${localStorage.getItem('ptit_dev_mode') === 'true' ? `
              <button id="ptit-lms-hud-scrape-btn" style="
                width: 100%;
                background: rgba(16, 185, 129, 0.1);
                color: #34d399;
                border: 1px solid rgba(16, 185, 129, 0.25);
                padding: 5px 12px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
              ">
                <span>🕷️ [DEV] Trích Xuất Quiz (.json)</span>
              </button>
              ` : ''}
            </div>
          </div>
        `;

        const closeBtn = hudElement.querySelector('#ptit-lms-hud-close');
        closeBtn.onclick = () => {
          isMinimized = true;
          renderHUDContent();
        };

        const toggleBtn = hudElement.querySelector('#ptit-lms-hud-toggle-loop');
        toggleBtn.onclick = () => {
          const newState = !(localStorage.getItem('ptit_lms_autoloop') === 'true');
          localStorage.setItem('ptit_lms_autoloop', newState ? 'true' : 'false');
          showToast(newState ? '🟢 Auto-Loop đã BẬT: Đang tự động quét & học!' : '⚪ Auto-Loop đã TẮT');
          renderHUDContent();
        };

        const syncGithubBtn = hudElement.querySelector('#ptit-lms-hud-sync-github');
        syncGithubBtn.onclick = () => {
          syncFromGitHub(ctx.courseCode);
        };

        const fileInput = hudElement.querySelector('#ptit-lms-hud-file-input');
        if (fileInput) {
          fileInput.onchange = (e) => {
            if (e.target.files && e.target.files[0]) {
              importFromLocalFile(e.target.files[0]);
            }
          };
        }

        const pasteBtn = hudElement.querySelector('#ptit-lms-hud-paste-btn');
        pasteBtn.onclick = () => {
          promptFastJSONImport();
        };

        const solveBtn = hudElement.querySelector('#ptit-lms-hud-solve-btn');
        solveBtn.onclick = () => {
          solveQuizOnPage();
        };

        const submitBtn = hudElement.querySelector('#ptit-lms-hud-submit-btn');
        submitBtn.onclick = () => {
          const res = solveQuizOnPage();
          if (res.answered > 0 || !res.dbEmpty) {
            setTimeout(() => {
              submitQuiz();
            }, 800);
          }
        };

        const skipVidBtn = hudElement.querySelector('#ptit-lms-hud-skip-vid');
        if (skipVidBtn) {
          skipVidBtn.onclick = () => {
            skipCurrentVideo();
          };
        }

        const speed2xBtn = hudElement.querySelector('#ptit-lms-hud-speed-2x');
        if (speed2xBtn) {
          speed2xBtn.onclick = () => {
            const v = document.querySelector('video');
            if (v) { v.playbackRate = 2.0; showToast('⚡ Tốc độ video: 2.0x'); }
            else showToast('⚠️ Không tìm thấy video trên trang!');
          };
        }

        const speed5xBtn = hudElement.querySelector('#ptit-lms-hud-speed-5x');
        if (speed5xBtn) {
          speed5xBtn.onclick = () => {
            const v = document.querySelector('video');
            if (v) { v.playbackRate = 5.0; showToast('🚀 Tốc độ video: 5.0x'); }
            else showToast('⚠️ Không tìm thấy video trên trang!');
          };
        }

        const scrapeBtn = hudElement.querySelector('#ptit-lms-hud-scrape-btn');
        if (scrapeBtn) {
          scrapeBtn.onclick = () => {
            exportCurrentQuizToJSON();
          };
        }
      }
    }

    window.addEventListener('ptit_storage_updated', () => {
      renderHUDContent();
    });

    if (loopInterval) clearInterval(loopInterval);
    loopInterval = setInterval(() => {
      runAutoLoopTick();
      renderHUDContent();
    }, 2500);

    window.ptitDev = function(enable) {
      if (typeof enable === 'undefined') {
        const cur = localStorage.getItem('ptit_dev_mode') === 'true';
        localStorage.setItem('ptit_dev_mode', cur ? 'false' : 'true');
      } else {
        localStorage.setItem('ptit_dev_mode', enable ? 'true' : 'false');
      }
      const state = localStorage.getItem('ptit_dev_mode') === 'true';
      console.log(`[PTIT-LMS] Developer Mode: ${state ? 'ENABLED 🟢 (Hiển thị nút trích xuất)' : 'DISABLED ⚪ (Ẩn nút trích xuất)'}`);
      renderHUDContent();
      return state;
    };
    window.__ptit_exportQuiz = exportCurrentQuizToJSON;

    setTimeout(injectLMSHUD, 1000);
  }

})();
