/**
 * PTIT LMS & S-Link Extension Unlock (Version 2.3.0)
 * Developed by GLGT67 (https://github.com/GLGT67)
 * Repository: https://github.com/GLGT67/PTIT-LMS-EXTENSION-UNLOCK
 * 
 * Features:
 * 1. LMS PTIT: Mở khóa tua video, tăng tốc độ 1x-16x, phím tắt điều khiển.
 * 2. S-Link PTIT: Tự động phát hiện và điền đánh giá bài giảng / giảng viên ngẫu nhiên 4-5 sao.
 *    Hỗ trợ tùy chọn Năm sinh viên (Năm 1, 2, 3, 4).
 */

(function () {
  'use strict';

  if (window.__PTIT_EXTENSION_UNLOCKED_v23__) return;
  window.__PTIT_EXTENSION_UNLOCKED_v23__ = true;

  console.log('%c[PTIT Extension Unlock 2.3] Developed by GLGT67 (https://github.com/GLGT67)', 'color: #10b981; font-weight: bold; font-size: 14px;');

  const hostname = window.location.hostname;
  const isLMS = hostname.includes('lms.ptit.edu.vn');
  const isSLink = hostname.includes('slink.ptit.edu.vn');

  function showToast(msg) {
    let toast = document.getElementById('ptit-lms-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ptit-lms-toast';
      toast.style.cssText = [
        'position: fixed',
        'top: 24px',
        'right: 24px',
        'background: rgba(15, 23, 42, 0.95)',
        'color: #ffffff',
        'padding: 12px 20px',
        'border-radius: 10px',
        'font-family: system-ui, -apple-system, sans-serif',
        'font-size: 14px',
        'font-weight: 600',
        'z-index: 2147483647',
        'box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5)',
        'border: 1px solid rgba(255, 255, 255, 0.2)',
        'transition: opacity 0.25s ease, transform 0.25s ease',
        'pointer-events: none',
        'opacity: 0'
      ].join(';');
      (document.body || document.documentElement).appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
    clearTimeout(toast.__timer);
    toast.__timer = setTimeout(() => {
      toast.style.opacity = '0';
    }, 2500);
  }

  if (isLMS || (!isSLink && document.querySelector('video'))) {
    initLMSVideoUnlocker();
  }

  function initLMSVideoUnlocker() {
    window.addEventListener('mousedown', function (e) {
      if (e.target && (e.target.tagName === 'VIDEO' || e.target.closest('video'))) {
        e.stopImmediatePropagation();
      }
    }, true);

    window.addEventListener('seeking', function (e) {
      if (e.target && e.target.tagName === 'VIDEO') {
        e.stopImmediatePropagation();
      }
    }, true);

    window.addEventListener('seeked', function (e) {
      if (e.target && e.target.tagName === 'VIDEO') {
        e.stopImmediatePropagation();
      }
    }, true);

    const blockSnapback = function (proto) {
      const orig = proto.addEventListener;
      proto.addEventListener = function (type, listener, options) {
        if (type === 'seeking' || type === 'seeked') {
          const fnStr = listener ? listener.toString() : '';
          if (fnStr.includes('currentTime') && (fnStr.includes('Math.max') || fnStr.includes('_.current') || fnStr.includes('maxWatched'))) {
            console.log('[PTIT LMS Extension Unlock 2.3] Đã chặn listener khóa tua:', type);
            return;
          }
        }
        return orig.call(this, type, listener, options);
      };
    };

    blockSnapback(HTMLMediaElement.prototype);
    blockSnapback(EventTarget.prototype);

    function unlockVideo(v) {
      if (!v || v.__ptit_v23_unlocked__) return;
      v.__ptit_v23_unlocked__ = true;

      v.controls = true;
      v.removeAttribute('controlsList');
      v.removeAttribute('disablepictureinpicture');

      injectVideoHUD(v);
      console.log('[PTIT LMS Extension Unlock 2.3] Đã mở khóa video:', v);
    }

    function scanVideos() {
      document.querySelectorAll('video').forEach(unlockVideo);

      if (window.YT && window.YT.Player && window.YT.Player.prototype) {
        const p = window.YT.Player.prototype;
        if (!p.__ptit_hooked__) {
          p.__ptit_hooked__ = true;
          const origSeekTo = p.seekTo;
          p.seekTo = function (sec, ahead) {
            return origSeekTo.call(this, sec, true);
          };
        }
      }
    }

    const observer = new MutationObserver(scanVideos);
    if (document.documentElement) {
      observer.observe(document.documentElement, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.documentElement, { childList: true, subtree: true });
      });
    }
    setInterval(scanVideos, 1000);

    function injectVideoHUD(video) {
      const parent = video.parentElement;
      if (!parent || parent.querySelector('.ptit-hud-bar')) return;

      if (getComputedStyle(parent).position === 'static') {
        parent.style.position = 'relative';
      }

      const hud = document.createElement('div');
      hud.className = 'ptit-hud-bar';
      hud.style.cssText = [
        'position: absolute',
        'top: 10px',
        'right: 10px',
        'display: flex',
        'gap: 6px',
        'z-index: 2147483647',
        'background: rgba(15, 23, 42, 0.88)',
        'padding: 6px 10px',
        'border-radius: 8px',
        'box-shadow: 0 4px 12px rgba(0,0,0,0.3)',
        'backdrop-filter: blur(6px)',
        'border: 1px solid rgba(255,255,255,0.2)'
      ].join(';');

      function createBtn(text, title, onClick) {
        const btn = document.createElement('button');
        btn.textContent = text;
        btn.title = title;
        btn.style.cssText = [
          'background: rgba(255, 255, 255, 0.15)',
          'color: #ffffff',
          'border: none',
          'padding: 4px 8px',
          'border-radius: 4px',
          'font-size: 12px',
          'font-weight: 600',
          'cursor: pointer',
          'transition: background 0.15s'
        ].join(';');
        btn.onmouseover = () => btn.style.background = 'rgba(239, 68, 68, 0.85)';
        btn.onmouseout = () => btn.style.background = 'rgba(255, 255, 255, 0.15)';
        btn.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          onClick();
        };
        return btn;
      }

      hud.appendChild(createBtn('⏪ -10s', 'Tua lùi 10 giây', () => {
        video.currentTime = Math.max(0, video.currentTime - 10);
        showToast('⏪ Đã tua lùi: ' + Math.round(video.currentTime) + 's');
      }));

      hud.appendChild(createBtn('⏩ +10s', 'Tua tới 10 giây', () => {
        video.currentTime = Math.min(video.duration || 99999, video.currentTime + 10);
        showToast('⏩ Đã tua tới: ' + Math.round(video.currentTime) + 's');
      }));

      hud.appendChild(createBtn('⏩ +1m', 'Tua tới 1 phút', () => {
        video.currentTime = Math.min(video.duration || 99999, video.currentTime + 60);
        showToast('⏩ Đã tua tới: ' + Math.round(video.currentTime) + 's');
      }));

      hud.appendChild(createBtn('⚡ 2x', 'Phát tốc độ 2.0x', () => {
        video.playbackRate = 2.0;
        showToast('⚡ Tốc độ: 2.0x');
      }));

      hud.appendChild(createBtn('🚀 5x', 'Phát tốc độ 5.0x', () => {
        video.playbackRate = 5.0;
        showToast('🚀 Tốc độ: 5.0x');
      }));

      hud.appendChild(createBtn('🎯 Xong', 'Nhảy đến gần cuối video để hoàn thành bài', () => {
        if (video.duration && video.duration > 2) {
          video.currentTime = video.duration - 2;
          video.play();
          showToast('🎯 Đã nhảy đến cuối video để hoàn thành bài!');
        }
      }));

      parent.appendChild(hud);
    }

    window.addEventListener('keydown', function (e) {
      if (['INPUT', 'TEXTAREA'].includes(e.target.tagName) || e.target.isContentEditable) return;

      const video = Array.from(document.querySelectorAll('video')).find(v => !v.paused) || document.querySelector('video');
      if (!video) return;

      if (e.key === 'ArrowRight') {
        e.preventDefault();
        video.currentTime = Math.min(video.duration || 999999, video.currentTime + 5);
        showToast('⏩ Tua tới: ' + Math.round(video.currentTime) + 's');
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        video.currentTime = Math.max(0, video.currentTime - 5);
        showToast('⏪ Tua lùi: ' + Math.round(video.currentTime) + 's');
      } else if (e.key === ']' || e.key === '=' || e.key === '+') {
        e.preventDefault();
        const speeds = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 16.0];
        const cur = video.playbackRate;
        const next = speeds.find(s => s > cur + 0.05) || 16.0;
        video.playbackRate = next;
        showToast('⚡ Tốc độ: ' + next + 'x');
      } else if (e.key === '[' || e.key === '-' || e.key === '_') {
        e.preventDefault();
        const speeds = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 16.0];
        const cur = video.playbackRate;
        const prev = [...speeds].reverse().find(s => s < cur - 0.05) || 1.0;
        video.playbackRate = prev;
        showToast('⚡ Tốc độ: ' + prev + 'x');
      }
    }, true);
  }

  if (isSLink || (!isLMS && window.location.href.includes('danh-gia-giang-vien'))) {
    initSLinkEvaluator();
  }

  function initSLinkEvaluator() {
    let hudElement = null;
    let isMinimized = false;

    function triggerTextInput(inputElement, text) {
      if (!inputElement) return;
      try {
        const proto = Object.getPrototypeOf(inputElement);
        const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
        if (desc && desc.set) {
          desc.set.call(inputElement, text);
        } else {
          inputElement.value = text;
        }
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        inputElement.dispatchEvent(new Event('change', { bubbles: true }));
      } catch (e) {
        inputElement.value = text;
      }
    }

    function isEvaluationPage() {
      const url = window.location.href;
      if (url.includes('danh-gia-giang-vien') || url.includes('khao-sat')) return true;

      const bodyText = document.body ? document.body.innerText : '';
      if (bodyText.includes('ĐÁNH GIÁ GIẢNG VIÊN') ||
          bodyText.includes('PHIẾU KHẢO SÁT Ý KIẾN NGƯỜI HỌC') ||
          bodyText.includes('Đợt đánh giá') ||
          bodyText.includes('Chất lượng bài giảng điện tử')) {
        return true;
      }

      if (document.querySelector('table') && (document.querySelector('.ant-radio-wrapper') || document.querySelector('.ant-checkbox-wrapper'))) {
        return true;
      }

      return false;
    }

    function runAutoFill() {
      let filledCount = 0;
      const savedYear = localStorage.getItem('ptit_slink_student_year') || 'Năm 3';

      function safeClickOption(element) {
        if (!element) return false;
        let clickable = element;
        if (element.tagName === 'TD' || element.tagName === 'DIV') {
          clickable = element.querySelector('label, .ant-checkbox-wrapper, .ant-radio-wrapper, .ant-checkbox, .ant-radio, input') || element;
        }
        const input = clickable.tagName === 'INPUT' ? clickable : clickable.querySelector('input');

        const isAlreadyChecked = (input && input.checked) ||
          (clickable.classList && (
            clickable.classList.contains('ant-checkbox-wrapper-checked') ||
            clickable.classList.contains('ant-radio-wrapper-checked') ||
            clickable.classList.contains('ant-checkbox-checked') ||
            clickable.classList.contains('ant-radio-checked')
          )) ||
          (element.classList && (
            element.classList.contains('ant-checkbox-wrapper-checked') ||
            element.classList.contains('ant-radio-wrapper-checked') ||
            element.classList.contains('ant-checkbox-checked') ||
            element.classList.contains('ant-radio-checked')
          ));

        if (isAlreadyChecked) return true;

        const targetToClick = clickable.querySelector('label, .ant-checkbox-wrapper, .ant-radio-wrapper') ||
                              (clickable.tagName === 'LABEL' ? clickable : null) ||
                              input ||
                              clickable;

        try {
          targetToClick.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
          targetToClick.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
          targetToClick.click();
        } catch (err) {
          targetToClick.click && targetToClick.click();
        }

        if (input && !input.checked) {
          try {
            const proto = Object.getPrototypeOf(input);
            const desc = Object.getOwnPropertyDescriptor(proto, 'checked') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked');
            if (desc && desc.set) {
              desc.set.call(input, true);
            } else {
              input.checked = true;
            }
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (e) {
            input.checked = true;
          }
        }

        filledCount++;
        return true;
      }

      function findOptionByText(keywords) {
        const allCandidates = Array.from(document.querySelectorAll('label, .ant-radio-wrapper, .ant-checkbox-wrapper, span, div'));
        for (const kw of keywords) {
          const kwLower = kw.toLowerCase();
          const found = allCandidates.find(el => {
            const txt = (el.textContent || '').trim().toLowerCase();
            return txt.includes(kwLower) && txt.length < 150;
          });
          if (found) {
            return found.closest('.ant-radio-wrapper, .ant-checkbox-wrapper, label, td') || found;
          }
        }
        return null;
      }

      function findOptionByExactText(text) {
        const allCandidates = Array.from(document.querySelectorAll('label, .ant-radio-wrapper, .ant-checkbox-wrapper, span'));
        const found = allCandidates.find(el => (el.textContent || '').trim() === text);
        if (found) {
          return found.closest('.ant-radio-wrapper, .ant-checkbox-wrapper, label, td') || found;
        }
        return null;
      }

      const a1 = findOptionByText(['kết hợp (blended', 'học kết hợp', 'blended learning', 'kết hợp', 'trực tuyến hoàn toàn']);
      safeClickOption(a1);

      const a2 = findOptionByText(['máy tính/laptop', 'máy tính', 'laptop', 'điện thoại']);
      safeClickOption(a2);

      const a3 = findOptionByText(['100% (hoàn thành', '100%', '76–99%']);
      safeClickOption(a3);

      const a4 = findOptionByExactText(savedYear) || findOptionByText([savedYear]);
      safeClickOption(a4);

      const allRows = Array.from(document.querySelectorAll('tr, .ant-table-row'));
      allRows.forEach(tr => {
        if (tr.querySelector('th') || tr.closest('thead')) return;

        const cells = Array.from(tr.querySelectorAll('td'));
        if (cells.length === 0) return;

        let chosenCell = null;

        if (cells.length >= 7) {
          chosenCell = Math.random() < 0.75 ? cells[6] : cells[5];
        } else if (cells.length === 6) {
          chosenCell = Math.random() < 0.75 ? cells[5] : cells[4];
        } else if (cells.length === 5) {
          chosenCell = Math.random() < 0.75 ? cells[4] : cells[3];
        } else {
          const optionCells = cells.filter(td => td.querySelector('input, label, .ant-checkbox, .ant-radio, .ant-checkbox-wrapper, .ant-radio-wrapper'));
          if (optionCells.length >= 5) {
            chosenCell = Math.random() < 0.75 ? optionCells[optionCells.length - 1] : optionCells[optionCells.length - 2];
          } else if (optionCells.length > 0) {
            chosenCell = optionCells[optionCells.length - 1];
          }
        }

        if (chosenCell) {
          safeClickOption(chosenCell);
        }
      });

      const pick10 = Math.random() < 0.7;
      const targetRating = pick10 ? '10' : '9';
      const allFormItems = Array.from(document.querySelectorAll('.ant-form-item, .ant-card, div'));
      const scale10Item = allFormItems.find(el => {
        const t = (el.textContent || '').toLowerCase();
        return (t.includes('thang điểm từ 1') || t.includes('1 (rất kém)') || t.includes('đến 10')) &&
               el.querySelectorAll('.ant-radio-wrapper, .ant-checkbox-wrapper, input').length >= 8;
      });

      if (scale10Item) {
        const opts = Array.from(scale10Item.querySelectorAll('.ant-radio-wrapper, .ant-checkbox-wrapper, label'));
        const opt10 = opts.find(o => (o.textContent || '').trim() === '10');
        const opt9 = opts.find(o => (o.textContent || '').trim() === '9');
        const chosen = (pick10 && opt10) ? opt10 : (opt9 || opt10 || opts[opts.length - 1]);
        if (chosen) safeClickOption(chosen);
      } else {
        const opt = (pick10) ? (findOptionByExactText('10') || findOptionByExactText('9')) : (findOptionByExactText('9') || findOptionByExactText('10'));
        if (opt) safeClickOption(opt);
      }

      const g5 = findOptionByText([
        'thảo luận/giải đáp trực tiếp',
        'kết hợp: tự học',
        'học kết hợp',
        'hoàn toàn qua bài giảng'
      ]);
      if (g5) {
        safeClickOption(g5);
      }

      const textareas = document.querySelectorAll('textarea, input[type="text"]');
      textareas.forEach(field => {
        if (field.classList.contains('ant-pagination-options-quick-jumper')) return;
        const parent = field.closest('.ant-form-item') || field.parentElement;
        const parentText = (parent ? parent.textContent : '').toLowerCase();

        if (parentText.includes('hài lòng nhất')) {
          triggerTextInput(field, 'Bài giảng điện tử được thiết kế rất khoa học, video rõ nét, âm thanh chuẩn, bài tập tương tác sinh động giúp nắm bắt kiến thức hiệu quả.');
          filledCount++;
        } else if (parentText.includes('cải thiện nhất')) {
          triggerTextInput(field, 'Bài giảng hiện tại rất đầy đủ và chất lượng; mong Thầy/Cô tiếp tục phát huy và cập nhật thêm các bài tập tình huống thực tế.');
          filledCount++;
        } else if (parentText.includes('bổ sung')) {
        } else {
          const isRequired = parentText.includes('*') || field.hasAttribute('required') || (parent && parent.querySelector('.ant-form-item-required'));
          if (isRequired && !field.value.trim()) {
            triggerTextInput(field, 'Nội dung bài giảng được thiết kế rất khoa học, dễ tiếp thu; Thầy/Cô nhiệt tình giảng dạy và giải đáp thắc mắc cho sinh viên.');
            filledCount++;
          }
        }
      });

      allRows.forEach(tr => {
        if (tr.querySelector('th') || tr.closest('thead')) return;
        const inputs = Array.from(tr.querySelectorAll('input[type="checkbox"], input[type="radio"], input'));
        const hasChecked = inputs.some(i => i.checked) ||
                           tr.querySelector('.ant-checkbox-checked, .ant-radio-checked, .ant-checkbox-wrapper-checked, .ant-radio-wrapper-checked');
        if (!hasChecked) {
          const cells = Array.from(tr.querySelectorAll('td'));
          if (cells.length > 0) {
            safeClickOption(cells[cells.length - 1]);
          }
        }
      });

      document.querySelectorAll('.ant-form-item, [role="radiogroup"], .ant-radio-group').forEach(formItem => {
        const text = formItem.textContent || '';
        const isRequired = text.includes('*') || formItem.querySelector('.ant-form-item-required');
        if (!isRequired) return;

        const inputs = Array.from(formItem.querySelectorAll('input[type="radio"], input[type="checkbox"]'));
        const hasChecked = inputs.some(i => i.checked) ||
                           formItem.querySelector('.ant-radio-wrapper-checked, .ant-checkbox-wrapper-checked, .ant-radio-checked, .ant-checkbox-checked');
        if (!hasChecked && inputs.length > 0) {
          const target = inputs[inputs.length - 1];
          safeClickOption(target.closest('label, .ant-radio-wrapper, .ant-checkbox-wrapper') || target);
        }
      });

      if (filledCount > 0) {
        showToast(`⚡ Đã điền xong đầy đủ phiếu đánh giá (${savedYear}, 4-5⭐)! Hãy kiểm tra và bấm Gửi.`);
      } else {
        showToast('⚠️ Không tìm thấy bảng khảo sát trên trang hiện tại.');
      }

      return filledCount;
    }

    function injectSLinkHUD() {
      if (document.getElementById('ptit-slink-hud')) return;

      hudElement = document.createElement('div');
      hudElement.id = 'ptit-slink-hud';
      hudElement.style.cssText = [
        'position: fixed',
        'bottom: 85px',
        'right: 24px',
        'z-index: 2147483640',
        'font-family: system-ui, -apple-system, sans-serif',
        'transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
      ].join(';');

      renderHUDContent();
      (document.body || document.documentElement).appendChild(hudElement);
    }

    function renderHUDContent() {
      if (!hudElement) return;

      const currentYear = localStorage.getItem('ptit_slink_student_year') || 'Năm 3';

      if (isMinimized) {
        hudElement.innerHTML = `
          <div id="ptit-slink-hud-pill" style="
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: #ffffff;
            padding: 10px 14px;
            border-radius: 30px;
            box-shadow: 0 10px 25px -5px rgba(239, 68, 68, 0.5);
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 700;
            border: 1px solid rgba(255, 255, 255, 0.25);
            transition: transform 0.2s ease;
          ">
            <span>⚡ Điền Đánh Giá (${currentYear})</span>
          </div>
        `;
        const pill = hudElement.querySelector('#ptit-slink-hud-pill');
        pill.onmouseover = () => pill.style.transform = 'scale(1.05)';
        pill.onmouseout = () => pill.style.transform = 'scale(1)';
        pill.onclick = () => {
          isMinimized = false;
          renderHUDContent();
        };
      } else {
        hudElement.innerHTML = `
          <div style="
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 14px 16px;
            box-shadow: 0 15px 35px -5px rgba(0, 0, 0, 0.6);
            width: 260px;
            color: #f8fafc;
          ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="font-size: 16px;">⚡</span>
                <span style="font-size: 13px; font-weight: 700; color: #fff;">PTIT S-Link Auto-Fill</span>
              </div>
              <button id="ptit-slink-hud-close" style="
                background: none;
                border: none;
                color: #94a3b8;
                font-size: 14px;
                cursor: pointer;
                padding: 2px 6px;
                border-radius: 4px;
              " title="Thu nhỏ">✕</button>
            </div>
            
            <p style="font-size: 11px; color: #94a3b8; margin-bottom: 10px; line-height: 1.4;">
              Điền toàn bộ tiêu chí B–F với mức ngẫu nhiên <b>4 - 5⭐</b>.
            </p>

            <!-- Ô CHỌN NĂM SINH VIÊN -->
            <div style="margin-bottom: 12px; background: rgba(30, 41, 59, 0.7); padding: 8px 10px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.1);">
              <label for="ptit-slink-student-year" style="font-size: 11px; font-weight: 700; color: #cbd5e1; display: block; margin-bottom: 4px;">
                🎓 Bạn là sinh viên năm:
              </label>
              <select id="ptit-slink-student-year" style="
                width: 100%;
                background: #0f172a;
                color: #f8fafc;
                border: 1px solid #475569;
                border-radius: 6px;
                padding: 5px 8px;
                font-size: 12px;
                font-weight: 600;
                cursor: pointer;
                outline: none;
              ">
                <option value="Năm 1">Năm 1</option>
                <option value="Năm 2">Năm 2</option>
                <option value="Năm 3">Năm 3</option>
                <option value="Năm 4">Năm 4</option>
                <option value="Khác">Câu trả lời khác</option>
              </select>
            </div>

            <button id="ptit-slink-btn-autofill" style="
              width: 100%;
              background: linear-gradient(135deg, #ef4444, #dc2626);
              color: #ffffff;
              border: none;
              padding: 9px 12px;
              border-radius: 8px;
              font-size: 13px;
              font-weight: 700;
              cursor: pointer;
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 6px;
              box-shadow: 0 4px 14px rgba(239, 68, 68, 0.4);
              transition: all 0.15s ease;
            ">
              <span>⚡ Điền Nhanh Đánh Giá</span>
            </button>
          </div>
        `;

        const yearSelect = hudElement.querySelector('#ptit-slink-student-year');
        if (yearSelect) {
          yearSelect.value = currentYear;
          yearSelect.onchange = (e) => {
            localStorage.setItem('ptit_slink_student_year', e.target.value);
            showToast(`🎓 Đã ghi nhớ: ${e.target.value}`);
          };
        }

        const closeBtn = hudElement.querySelector('#ptit-slink-hud-close');
        closeBtn.onclick = () => {
          isMinimized = true;
          renderHUDContent();
        };

        const fillBtn = hudElement.querySelector('#ptit-slink-btn-autofill');
        fillBtn.onmouseover = () => fillBtn.style.transform = 'translateY(-1px)';
        fillBtn.onmouseout = () => fillBtn.style.transform = 'translateY(0)';
        fillBtn.onclick = (e) => {
          e.preventDefault();
          fillBtn.innerHTML = '<span>⏳ Đang điền...</span>';
          setTimeout(() => {
            runAutoFill();
            setTimeout(() => {
              runAutoFill();
            }, 300);
            fillBtn.innerHTML = `<span>✓ Đã điền xong!</span>`;
            setTimeout(() => {
              fillBtn.innerHTML = '<span>⚡ Điền Nhanh Đánh Giá</span>';
            }, 3000);
          }, 150);
        };
      }
    }

    function checkHUDVisibility() {
      if (isEvaluationPage()) {
        if (!hudElement) {
          injectSLinkHUD();
        } else {
          hudElement.style.display = 'block';
        }
      } else {
        if (hudElement) {
          hudElement.style.display = 'none';
        }
      }
    }

    window.addEventListener('hashchange', checkHUDVisibility);
    window.addEventListener('popstate', checkHUDVisibility);

    const origPushState = history.pushState;
    if (origPushState) {
      history.pushState = function () {
        origPushState.apply(this, arguments);
        setTimeout(checkHUDVisibility, 300);
      };
    }

    const origReplaceState = history.replaceState;
    if (origReplaceState) {
      history.replaceState = function () {
        origReplaceState.apply(this, arguments);
        setTimeout(checkHUDVisibility, 300);
      };
    }

    setInterval(checkHUDVisibility, 1500);

    const domObserver = new MutationObserver(() => {
      checkHUDVisibility();
    });

    if (document.body) {
      domObserver.observe(document.body, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        domObserver.observe(document.body, { childList: true, subtree: true });
        checkHUDVisibility();
      });
    }

    setTimeout(checkHUDVisibility, 500);
  }

})();
