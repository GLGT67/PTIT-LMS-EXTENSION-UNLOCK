// ==UserScript==
// @name         PTIT LMS - Extension Unlock
// @namespace    https://lms.ptit.edu.vn/
// @version      2.2.0
// @description  Mở khóa tính năng tua video trên LMS PTIT (Hỗ trợ YouTube & Video nội bộ HTML5 môn Triết học BAS1152).
// @author       GLGT67
// @homepageURL  https://github.com/GLGT67/PTIT-LMS-EXTENSION-UNLOCK
// @match        https://lms.ptit.edu.vn/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

/**
 * PTIT LMS - Extension Unlock (Version 2.2.0)
 * Developed by GLGT67 (https://github.com/GLGT67)
 * Repository: https://github.com/GLGT67/PTIT-LMS-EXTENSION-UNLOCK
 */
(function () {
  'use strict';

  if (window.__PTIT_UNLOCK_SEEK_v22__) return;
  window.__PTIT_UNLOCK_SEEK_v22__ = true;

  console.log('%c[PTIT LMS Extension Unlock 2.2] Developed by GLGT67 (https://github.com/GLGT67)', 'color: #10b981; font-weight: bold; font-size: 14px;');

  // ========================================================
  // 1. TRIỆT TIÊU BỘ CHẶN TUA TRÊN NEXT.JS / REACT CỦA PTIT
  // ========================================================

  // CHẶN 1: Bẻ gãy onMouseDown preventDefault() của React trên thẻ <video>
  window.addEventListener('mousedown', function (e) {
    if (e.target && (e.target.tagName === 'VIDEO' || e.target.closest('video'))) {
      e.stopImmediatePropagation();
    }
  }, true);

  // CHẶN 2: Ngắt các sự kiện 'seeking' và 'seeked' truyền lên React
  window.addEventListener('seeking', function (e) {
    if (e.target && e.target.tagName === 'VIDEO') {
      e.stopImmediatePropagation();
    }
  }, true);

  window.addEventListener('seeked', function (e) {
    if (e.target && e.target.tagName === 'VIDEO') {
      e.stopImmediatePropagation();
    }
  }, true);

  // CHẶN 3: Lọc và tiêu diệt mọi listener snapback gắn trực tiếp qua addEventListener
  const blockSnapback = function (proto) {
    const orig = proto.addEventListener;
    proto.addEventListener = function (type, listener, options) {
      if (type === 'seeking' || type === 'seeked') {
        const fnStr = listener ? listener.toString() : '';
        if (fnStr.includes('currentTime') && (fnStr.includes('Math.max') || fnStr.includes('_.current') || fnStr.includes('maxWatched'))) {
          console.log('[PTIT LMS Extension Unlock 2.2] Đã chặn listener khóa tua:', type);
          return;
        }
      }
      return orig.call(this, type, listener, options);
    };
  };

  blockSnapback(HTMLMediaElement.prototype);
  blockSnapback(EventTarget.prototype);

  // ========================================================
  // 2. MỞ KHÓA THẺ <video> VÀ TỰ ĐỘNG THÊM THANH ĐIỀU KHIỂN NATIVE
  // ========================================================

  function unlockVideo(v) {
    if (!v || v.__ptit_v22_unlocked__) return;
    v.__ptit_v22_unlocked__ = true;

    v.controls = true;
    v.removeAttribute('controlsList');
    v.removeAttribute('disablepictureinpicture');

    injectVideoHUD(v);
    console.log('[PTIT LMS Extension Unlock 2.2] Đã mở khóa video:', v);
  }

  function scanVideos() {
    document.querySelectorAll('video').forEach(unlockVideo);

    if (window.YT && window.YT.Player && window.YT.Player.prototype) {
      const p = window.YT.Player.prototype;
      if (!p.__ptit_hooked__) {
        p.__ptit_hooked__ = true;
        const origSeekTo = p.seekTo;
        p.seekTo = function (sec, ahead) {
          return origSeekTo.call(this, sec, true);
        };
      }
    }
  }

  const observer = new MutationObserver(scanVideos);
  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.documentElement, { childList: true, subtree: true });
    });
  }
  setInterval(scanVideos, 1000);

  // ========================================================
  // 3. THANH ĐIỀU KHIỂN NỔI (HUD BUTTONS TRÊN VIDEO)
  // ========================================================

  function injectVideoHUD(video) {
    const parent = video.parentElement;
    if (!parent || parent.querySelector('.ptit-hud-bar')) return;

    if (getComputedStyle(parent).position === 'static') {
      parent.style.position = 'relative';
    }

    const hud = document.createElement('div');
    hud.className = 'ptit-hud-bar';
    hud.style.cssText = [
      'position: absolute',
      'top: 10px',
      'right: 10px',
      'display: flex',
      'gap: 6px',
      'z-index: 2147483647',
      'background: rgba(15, 23, 42, 0.88)',
      'padding: 6px 10px',
      'border-radius: 8px',
      'box-shadow: 0 4px 12px rgba(0,0,0,0.3)',
      'backdrop-filter: blur(6px)',
      'border: 1px solid rgba(255,255,255,0.2)'
    ].join(';');

    function createBtn(text, title, onClick) {
      const btn = document.createElement('button');
      btn.textContent = text;
      btn.title = title;
      btn.style.cssText = [
        'background: rgba(255, 255, 255, 0.15)',
        'color: #ffffff',
        'border: none',
        'padding: 4px 8px',
        'border-radius: 4px',
        'font-size: 12px',
        'font-weight: 600',
        'cursor: pointer',
        'transition: background 0.15s'
      ].join(';');
      btn.onmouseover = () => btn.style.background = 'rgba(239, 68, 68, 0.85)';
      btn.onmouseout = () => btn.style.background = 'rgba(255, 255, 255, 0.15)';
      btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      };
      return btn;
    }

    hud.appendChild(createBtn('⏪ -10s', 'Tua lùi 10 giây', () => {
      video.currentTime = Math.max(0, video.currentTime - 10);
      showToast('⏪ Đã tua lùi: ' + Math.round(video.currentTime) + 's');
    }));

    hud.appendChild(createBtn('⏩ +10s', 'Tua tới 10 giây', () => {
      video.currentTime = Math.min(video.duration || 99999, video.currentTime + 10);
      showToast('⏩ Đã tua tới: ' + Math.round(video.currentTime) + 's');
    }));

    hud.appendChild(createBtn('⏩ +1m', 'Tua tới 1 phút', () => {
      video.currentTime = Math.min(video.duration || 99999, video.currentTime + 60);
      showToast('⏩ Đã tua tới: ' + Math.round(video.currentTime) + 's');
    }));

    hud.appendChild(createBtn('⚡ 2x', 'Phát tốc độ 2.0x', () => {
      video.playbackRate = 2.0;
      showToast('⚡ Tốc độ: 2.0x');
    }));

    hud.appendChild(createBtn('🚀 5x', 'Phát tốc độ 5.0x', () => {
      video.playbackRate = 5.0;
      showToast('🚀 Tốc độ: 5.0x');
    }));

    hud.appendChild(createBtn('🎯 Xong', 'Nhảy đến gần cuối video để hoàn thành bài', () => {
      if (video.duration && video.duration > 2) {
        video.currentTime = video.duration - 2;
        video.play();
        showToast('🎯 Đã nhảy đến cuối video để hoàn thành bài!');
      }
    }));

    parent.appendChild(hud);
  }

  // ========================================================
  // 4. BẢNG THÔNG BÁO (TOAST HUD) & PHÍM TẮT
  // ========================================================
  function showToast(msg) {
    let toast = document.getElementById('ptit-lms-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ptit-lms-toast';
      toast.style.cssText = [
        'position: fixed',
        'top: 24px',
        'right: 24px',
        'background: rgba(15, 23, 42, 0.95)',
        'color: #ffffff',
        'padding: 10px 18px',
        'border-radius: 10px',
        'font-family: system-ui, sans-serif',
        'font-size: 14px',
        'font-weight: 600',
        'z-index: 2147483647',
        'box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5)',
        'border: 1px solid rgba(255, 255, 255, 0.2)',
        'transition: opacity 0.2s ease, transform 0.2s ease',
        'pointer-events: none',
        'opacity: 0'
      ].join(';');
      (document.body || document.documentElement).appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
    clearTimeout(toast.__timer);
    toast.__timer = setTimeout(() => {
      toast.style.opacity = '0';
    }, 1500);
  }

  window.addEventListener('keydown', function (e) {
    if (['INPUT', 'TEXTAREA'].includes(e.target.tagName) || e.target.isContentEditable) return;

    const video = Array.from(document.querySelectorAll('video')).find(v => !v.paused) || document.querySelector('video');
    if (!video) return;

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      video.currentTime = Math.min(video.duration || 999999, video.currentTime + 5);
      showToast('⏩ Tua tới: ' + Math.round(video.currentTime) + 's');
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      video.currentTime = Math.max(0, video.currentTime - 5);
      showToast('⏪ Tua lùi: ' + Math.round(video.currentTime) + 's');
    } else if (e.key === ']' || e.key === '=' || e.key === '+') {
      e.preventDefault();
      const speeds = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 16.0];
      const cur = video.playbackRate;
      const next = speeds.find(s => s > cur + 0.05) || 16.0;
      video.playbackRate = next;
      showToast('⚡ Tốc độ: ' + next + 'x');
    } else if (e.key === '[' || e.key === '-' || e.key === '_') {
      e.preventDefault();
      const speeds = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 16.0];
      const cur = video.playbackRate;
      const prev = [...speeds].reverse().find(s => s < cur - 0.05) || 1.0;
      video.playbackRate = prev;
      showToast('⚡ Tốc độ: ' + prev + 'x');
    }
  }, true);

})();
