// Content Loader: Tiêm main.js trực tiếp vào trang web (MAIN World) ngay lập tức
// Developed by GLGT67 (https://github.com/GLGT67)
(function () {
  'use strict';
  try {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('main.js');
    s.async = false;
    s.onload = function () { this.remove(); };
    (document.head || document.documentElement).appendChild(s);
  } catch (e) {
    console.error('[PTIT LMS Extension Unlock] Lỗi loader:', e);
  }
})();
