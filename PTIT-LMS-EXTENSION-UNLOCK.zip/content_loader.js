
(function () {
  'use strict';
  try {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('main.js');
    s.async = false;
    s.onload = function () { this.remove(); };
    (document.head || document.documentElement).appendChild(s);
  } catch (e) {
    console.error('[PTIT LMS Extension Unlock] Lỗi loader:', e);
  }
})();
